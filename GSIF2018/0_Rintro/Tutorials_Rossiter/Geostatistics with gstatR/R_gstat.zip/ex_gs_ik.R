### R code from vignette source 'ex_gs_ik.Rnw'

###################################################
### code chunk number 1: ex_gs_ik.Rnw:29-31
###################################################
meuse$zn.i <- (meuse$zinc < 150)
summary(meuse$zn.i)


###################################################
### code chunk number 2: ex_gs_ik.Rnw:42-44
###################################################
vi <- variogram(zn.i ~ 1, location=meuse, cutoff=1300)
print(plot(vi, pl=T))


###################################################
### code chunk number 3: ex_gs_ik.Rnw:47-49
###################################################
(vimf <- fit.variogram(vi, vgm(0.12, "Sph", 1300, 0)))
print(plot(vi, pl=T, model=vimf))


###################################################
### code chunk number 4: ex_gs_ik.Rnw:69-71
###################################################
k40.i <- krige(zn.i ~ 1, loc=meuse, newdata=meuse.grid, model=vimf)
print(spplot(k40.i, zcol="var1.pred", col.regions=heat.colors(64), asp=1, main="Probability Zn < 150"))



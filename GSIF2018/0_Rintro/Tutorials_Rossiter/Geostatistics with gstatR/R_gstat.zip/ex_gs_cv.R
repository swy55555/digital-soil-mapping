### R code from vignette source 'ex_gs_cv.Rnw'

###################################################
### code chunk number 1: ex_gs_cv.Rnw:43-46
###################################################
kcv.ok <- krige.cv(zinc.l ~ 1, locations=meuse, model=vmf)
kcv.rk <- krige.cv(zinc.l ~ ffreq, locations=meuse, model=vrmf)
kcv.rk2 <- krige.cv(zinc.l ~ ffreq*dist, locations=meuse, model=vrm2f)


###################################################
### code chunk number 2: ex_gs_cv.Rnw:55-56
###################################################
summary(kcv.ok)


###################################################
### code chunk number 3: ex_gs_cv.Rnw:67-70
###################################################
summary(kcv.ok$residual)
summary(kcv.rk$residual)
summary(kcv.rk2$residual)


###################################################
### code chunk number 4: ex_gs_cv.Rnw:79-82
###################################################
sqrt(sum(kcv.ok$residual^2)/length(kcv.ok$residual))
sqrt(sum(kcv.rk$residual^2)/length(kcv.rk$residual))
sqrt(sum(kcv.rk2$residual^2)/length(kcv.rk$residual))


###################################################
### code chunk number 5: ex_gs_cv.Rnw:99-105
###################################################
(zmax <- round(max(kcv.ok$residual,kcv.rk$residual,kcv.rk2$residual),2) + 0.01)
(zmin <- round(min(kcv.ok$residual,kcv.rk$residual,kcv.rk2$residual),2) - 0.01)
ramp <-  quantile(c(kcv.ok$residual,kcv.rk$residual,kcv.rk2$residual), probs=seq(0, 1, by=0.1))
p1 <- bubble(kcv.ok, zcol="residual", main="OK X-validation residuals", key.entries=ramp, pch=1)
p2 <- bubble(kcv.rk, zcol="residual", main="KED ffreq X-validation residuals", key.entries=ramp, pch=1)
p3 <- bubble(kcv.rk2, zcol="residual", main="KED ffreq*dist X-validation residuals", key.entries=ramp, pch=1)


###################################################
### code chunk number 6: ex_gs_cv.Rnw:112-115
###################################################
plot(p1, split=c(1,1,3,1), more=T)
plot(p2, split=c(2,1,3,1), more=T)
plot(p3, split=c(3,1,3,1), more=F)


###################################################
### code chunk number 7: ex_gs_cv.Rnw:126-127
###################################################
rm(zmax, zmin, ramp, p1, p2, p3)


###################################################
### code chunk number 8: ex_gs_cv.Rnw:132-133
###################################################
save.image(file="minimal_geostat_day2.RData")


###################################################
### code chunk number 9: ex_gs_cv.Rnw:139-140 (eval = FALSE)
###################################################
## q()



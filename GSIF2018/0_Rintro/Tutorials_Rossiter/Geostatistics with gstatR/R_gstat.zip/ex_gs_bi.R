### R code from vignette source 'ex_gs_bi.Rnw'

###################################################
### code chunk number 1: ex_gs_bi.Rnw:23-24
###################################################
plot(meuse$zinc.l ~ meuse$copper.l)


###################################################
### code chunk number 2: ex_gs_bi.Rnw:47-48
###################################################
pairs(meuse[,15:18])


###################################################
### code chunk number 3: ex_gs_bi.Rnw:72-73
###################################################
table(meuse$ffreq)


###################################################
### code chunk number 4: ex_gs_bi.Rnw:78-79
###################################################
boxplot(meuse$zinc.l ~ meuse$ffreq, xlab="Flood frequency class", ylab="log10-Zn ppm", main="Metal concentration per flood frequency class", boxwex=0.5, col="lightblue", notch=T)


###################################################
### code chunk number 5: ex_gs_bi.Rnw:91-92
###################################################
m.lzn.ff <- lm(zinc.l ~ ffreq, data=meuse)


###################################################
### code chunk number 6: ex_gs_bi.Rnw:105-108
###################################################
ls()
class(meuse)
class(m.lzn.ff)


###################################################
### code chunk number 7: ex_gs_bi.Rnw:121-122
###################################################
summary(m.lzn.ff)



### R code from vignette source 'ex_gs_rk.Rnw'

###################################################
### code chunk number 1: ex_gs_rk.Rnw:22-24
###################################################
summary(meuse.grid$ffreq)
print(spplot(meuse.grid, zcol="ffreq", col.regions=topo.colors(3), main="Flooding frequency"))


###################################################
### code chunk number 2: ex_gs_rk.Rnw:36-40
###################################################
k.ffreq <- krige(zinc.l ~ ffreq, locations=meuse,
                 newdata=meuse.grid, model=NULL)
print(spplot(k.ffreq, zcol="var1.pred", col.regions=bpy.colors(64),
             main="prediction by flood frequency, log-ppm Zn"))


###################################################
### code chunk number 3: ex_gs_rk.Rnw:45-47
###################################################
print(spplot(k.ffreq, zcol="var1.var",
             main="prediction variance, log-ppm Zn^2"))


###################################################
### code chunk number 4: ex_gs_rk.Rnw:65-69
###################################################
(vr <- variogram(zinc.l ~ ffreq, location=meuse,
                 cutoff=1300, width=90))
print(plot(vr, plot.numbers=T,
           main="Residuals, flood frequency co-variable"))


###################################################
### code chunk number 5: ex_gs_rk.Rnw:83-85
###################################################
(vrmf <- fit.variogram(vr, vgm(psill=0.08, model="Sph", range=700, nugget=0.01)))
print(vmf)


###################################################
### code chunk number 6: ex_gs_rk.Rnw:90-92
###################################################
print(plot(vr, plot.numbers=T, main="Residuals, flood frequency co-variable",
           model=vrmf))


###################################################
### code chunk number 7: ex_gs_rk.Rnw:114-115
###################################################
kr40 <- krige(zinc.l ~ ffreq, locations=meuse, newdata=meuse.grid, model=vrmf)


###################################################
### code chunk number 8: ex_gs_rk.Rnw:124-126
###################################################
print(spplot(kr40, "var1.pred", asp=1, col.regions=bpy.colors(64),
             main="KED-ffreq prediction, log-ppm Zn"))


###################################################
### code chunk number 9: ex_gs_rk.Rnw:142-151
###################################################
(zmax <- max(k40$var1.pred,kr40$var1.pred))
(zmin <- min(k40$var1.pred,kr40$var1.pred))
(zmax <- round(zmax, 1) + 0.1)
(zmin <- round(zmin, 1) - 0.1)
(ramp <- seq(from=zmin, to=zmax, by=.1))
p1 <- spplot(k40, "var1.pred", asp=1, main="OK prediction",
             at=ramp, col.regions=bpy.colors(64))
p2 <- spplot(kr40, "var1.pred", asp=1, main="KED-ffreq prediction",
             at=ramp, col.regions=bpy.colors(64))


###################################################
### code chunk number 10: ex_gs_rk.Rnw:157-159
###################################################
plot(p1, split=c(1,1,2,1), more=T)
plot(p2, split=c(2,1,2,1), more=F)


###################################################
### code chunk number 11: ex_gs_rk.Rnw:171-173
###################################################
print(spplot(kr40, "var1.var", asp=1,
             main="KED prediction variance, log-ppm Zn^2"))


###################################################
### code chunk number 12: ex_gs_rk.Rnw:181-183
###################################################
summary(kr40$var1.var)
summary(k40$var1.var)


###################################################
### code chunk number 13: ex_gs_rk.Rnw:188-195
###################################################
zmax <- round(max(k40$var1.var,kr40$var1.var), 3) + 0.001
zmin <- round(min(k40$var1.var,kr40$var1.var), 3) - 0.001
(ramp <- seq(from=zmin, to=zmax, by=.005))
p1 <- spplot(k40, "var1.var", asp=1, at=ramp,
             main="OK prediction variance, log-ppm Zn")
p2 <- spplot(kr40, "var1.var", asp=1, at=ramp,
             main="KED-ffreq prediction variance, log-ppm Zn")


###################################################
### code chunk number 14: ex_gs_rk.Rnw:199-201
###################################################
plot(p1, split=c(1,1,2,1), more=T)
plot(p2, split=c(2,1,2,1), more=F)


###################################################
### code chunk number 15: ex_gs_rk.Rnw:218-220
###################################################
names(meuse.grid)
intersect(names(meuse), names(meuse.grid))


###################################################
### code chunk number 16: ex_gs_rk.Rnw:234-237
###################################################
print(spplot(meuse.grid, zcol="dist",
             main="Normalized distance to river",
             col.regions=topo.colors(64)))


###################################################
### code chunk number 17: ex_gs_rk.Rnw:247-249
###################################################
plot(zinc.l ~ dist, data=meuse@data, col=meuse$ffreq)
legend(x=0.7, y=3.2, legend=c("1","2","3"), pch=1, col=1:3)


###################################################
### code chunk number 18: ex_gs_rk.Rnw:262-264
###################################################
m.lzn.dist <- lm(zinc.l ~ dist, data=meuse)
summary(m.lzn.dist)


###################################################
### code chunk number 19: ex_gs_rk.Rnw:277-283
###################################################
k.dist <- krige(zinc.l ~ dist, locations=meuse,
                newdata=meuse.grid, model=NULL)
p1 <- spplot(k.dist, zcol="var1.pred", col.regions=bpy.colors(64),
             main="prediction, log-ppm Zn")
p2 <- spplot(k.dist, zcol="var1.var",
             main="prediction variance, log-ppm Zn^2")


###################################################
### code chunk number 20: ex_gs_rk.Rnw:291-298
###################################################
require(lattice)
tmp <- lattice.options()
lattice.options(layout.widths =
       list(key.right = list(x = 3, units = "cm", data = NULL)))
print(p1, split=c(1,1,2,1), more=T)
print(p2, split=c(2,1,2,1), more=F)
lattice.options(tmp)


###################################################
### code chunk number 21: ex_gs_rk.Rnw:314-317
###################################################
m.lzn.ff.dist <- lm(zinc.l ~ ffreq + dist, data=meuse)
m.lzn.ff.dist.i <- lm(zinc.l ~ ffreq * dist, data=meuse)
anova(m.lzn.ff.dist.i, m.lzn.ff.dist, m.lzn.dist, m.lzn.ff)


###################################################
### code chunk number 22: ex_gs_rk.Rnw:338-339
###################################################
AIC(m.lzn.dist, m.lzn.ff, m.lzn.ff.dist, m.lzn.ff.dist.i)


###################################################
### code chunk number 23: ex_gs_rk.Rnw:352-353
###################################################
summary(m.lzn.ff.dist.i)


###################################################
### code chunk number 24: ex_gs_rk.Rnw:384-387
###################################################
par(mfrow=c(1,3))
plot(m.lzn.ff.dist.i, which=c(1,2,5))
par(mfrow=c(1,1))


###################################################
### code chunk number 25: ex_gs_rk.Rnw:408-410
###################################################
meuse@data[69,]
row.names(meuse@data)[69]


###################################################
### code chunk number 26: ex_gs_rk.Rnw:422-426
###################################################
bad.pt <- c(50,69,152)
bad.row <- (row(meuse@data)[,1] %in% bad.pt)
(bad.row.names <- row.names(meuse@data)[bad.row])
table(bad.row)


###################################################
### code chunk number 27: ex_gs_rk.Rnw:430-435
###################################################
colours.ffreq = c("red","orange","green")
plot(coordinates(meuse), asp=1, col=colours.ffreq[meuse$ffreq], pch=ifelse(bad.row, 20, 1), cex=4*meuse$zinc/max(meuse$zinc), main="Suspicious regression residuals (solid circles)", sub="Symbol size proportional to Zn concentration")
grid()
legend(178000, 333000, pch=1, col=colours.ffreq, legend=c("Frequent", "Occasional", "Rare"))
text(coordinates(meuse)[bad.row,], bad.row.names, pos=4)


###################################################
### code chunk number 28: ex_gs_rk.Rnw:444-445
###################################################
rm(bad.pt, bad.row, bad.row.names)


###################################################
### code chunk number 29: ex_gs_rk.Rnw:458-460
###################################################
(vr2 <- variogram(zinc.l ~ ffreq*dist, location=meuse, cutoff=1300, width=90))
print(plot(vr2, plot.numbers=T, main="Residuals, ffreq*dist"))


###################################################
### code chunk number 30: ex_gs_rk.Rnw:463-466
###################################################
(vrm2f <- fit.variogram(vr2, vgm(psill=0.04, model="Sph", range=700, nugget=0.01)))
vrmf
vmf


###################################################
### code chunk number 31: ex_gs_rk.Rnw:469-470
###################################################
print(plot(vr2, plot.numbers=T, model=vrm2f, main="Residuals, ffreq*dist"))


###################################################
### code chunk number 32: ex_gs_rk.Rnw:484-485
###################################################
kr240 <- krige(zinc.l ~ ffreq*dist, locations=meuse, newdata=meuse.grid, model=vrm2f)


###################################################
### code chunk number 33: ex_gs_rk.Rnw:495-496
###################################################
print(spplot(kr240, "var1.pred", asp=1, col.regions=bpy.colors(64), main="KED-ffreq*dist prediction, log-ppm Zn"))


###################################################
### code chunk number 34: ex_gs_rk.Rnw:514-523
###################################################
zmax <- round(max(k40$var1.pred,kr40$var1.pred,kr240$var1.pred), 1) + 0.1
zmin <- round(min(k40$var1.pred,kr40$var1.pred,kr240$var1.pred), 1) - 0.1
ramp <- seq(from=zmin, to=zmax, by=.1)
p1 <- spplot(k40, "var1.pred", asp=1, col.regions=bpy.colors(64),
             main="OK prediction, log-ppm Zn", at=ramp)
p2 <- spplot(kr40, "var1.pred", asp=1, col.regions=bpy.colors(64),
             main="KED-ffreq prediction, log-ppm Zn", at=ramp)
p3 <- spplot(kr240, "var1.pred", asp=1, col.regions=bpy.colors(64),
             main="KED-ffreq*dist prediction, log-ppm Zn", at=ramp)


###################################################
### code chunk number 35: ex_gs_rk.Rnw:528-531
###################################################
plot(p1, split=c(1,1,3,1), more=T)
plot(p2, split=c(2,1,3,1), more=T)
plot(p3, split=c(3,1,3,1), more=F)


###################################################
### code chunk number 36: ex_gs_rk.Rnw:544-547
###################################################
summary(kr240$var1.var)
summary(kr40$var1.var)
summary(k40$var1.var)


###################################################
### code chunk number 37: ex_gs_rk.Rnw:550-559
###################################################
zmax <- round(max(k40$var1.var,kr40$var1.var, kr240$var1.var), 3) + 0.001
zmin <- round(min(k40$var1.var,kr40$var1.var, kr240$var1.var), 3) - 0.001
(ramp <- seq(from=zmin, to=zmax, by=.005))
p1 <- spplot(k40, "var1.var", asp=1, at=ramp,
             main="OK prediction variance, log-ppm Zn")
p2 <- spplot(kr40, "var1.var", asp=1, at=ramp,
             main="KED-ffreq prediction variance, log-ppm Zn")
p3 <- spplot(kr240, "var1.var", asp=1, at=ramp,
             main="KED-ffreq*dist prediction variance, log-ppm Zn")


###################################################
### code chunk number 38: ex_gs_rk.Rnw:564-567
###################################################
plot(p1, split=c(1,1,3,1), more=T)
plot(p2, split=c(2,1,3,1), more=T)
plot(p3, split=c(3,1,3,1), more=F)



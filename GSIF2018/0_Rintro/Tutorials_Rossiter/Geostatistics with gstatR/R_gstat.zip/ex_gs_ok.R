### R code from vignette source 'ex_gs_ok.Rnw'

###################################################
### code chunk number 1: ex_gs_ok.Rnw:159-162
###################################################
data(meuse.grid)
coordinates(meuse.grid) <-c ("x","y")
gridded(meuse.grid) <- T


###################################################
### code chunk number 2: ex_gs_ok.Rnw:176-177
###################################################
k40 <- krige(zinc.l ~ 1, locations=meuse, newdata=meuse.grid, model=vmf)


###################################################
### code chunk number 3: ex_gs_ok.Rnw:188-189
###################################################
str(k40)


###################################################
### code chunk number 4: ex_gs_ok.Rnw:198-200
###################################################
print(spplot(k40, "var1.pred", asp=1, col.regions=bpy.colors(64),
             main="OK prediction, log-ppm Zn"))


###################################################
### code chunk number 5: ex_gs_ok.Rnw:216-218
###################################################
print(spplot(k40, "var1.var", asp=1,
             main="OK prediction variance, log-ppm Zn^2"))


###################################################
### code chunk number 6: ex_gs_ok.Rnw:242-243
###################################################
save.image(file="minimal_geostat.RData")


###################################################
### code chunk number 7: ex_gs_ok.Rnw:249-250 (eval = FALSE)
###################################################
## q()



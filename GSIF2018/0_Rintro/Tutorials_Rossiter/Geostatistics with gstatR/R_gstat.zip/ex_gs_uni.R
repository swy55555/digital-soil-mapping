### R code from vignette source 'ex_gs_uni.Rnw'

###################################################
### code chunk number 1: ex_gs_uni.Rnw:20-22
###################################################
meuse$zinc
sort(meuse$zinc)


###################################################
### code chunk number 2: ex_gs_uni.Rnw:31-34
###################################################
stem(meuse$zinc)
hist(meuse$zinc, breaks=16)
summary(meuse$zinc)


###################################################
### code chunk number 3: ex_gs_uni.Rnw:60-63
###################################################
meuse$zinc.l <- log10(meuse$zinc)
hist(meuse$zinc.l, breaks=16)
summary(meuse$zinc.l)


###################################################
### code chunk number 4: ex_gs_uni.Rnw:70-72
###################################################
head(meuse$zinc)
head(meuse$zinc.l)


###################################################
### code chunk number 5: ex_gs_uni.Rnw:86-90
###################################################
meuse$cadmium.l<-log10(meuse$cadmium)
meuse$copper.l<-log10(meuse$copper)
meuse$lead.l<-log10(meuse$lead)
str(meuse)



### R code from vignette source 'ex_gs_spatvar.Rnw'

###################################################
### code chunk number 1: ex_gs_spatvar.Rnw:21-24
###################################################
class(meuse)
coordinates(meuse) <- c("x","y")
class(meuse)


###################################################
### code chunk number 2: ex_gs_spatvar.Rnw:35-36
###################################################
str(meuse)


###################################################
### code chunk number 3: ex_gs_spatvar.Rnw:55-58
###################################################
plot(meuse, asp=1, pch=1)
data(meuse.riv)
lines(meuse.riv)


###################################################
### code chunk number 4: ex_gs_spatvar.Rnw:73-75
###################################################
plot(meuse, asp=1, cex=4*meuse$zinc/max(meuse$zinc), pch=1)
lines(meuse.riv)


###################################################
### code chunk number 5: ex_gs_spatvar.Rnw:104-106
###################################################
n <- length(meuse$zinc.l)
n*(n-1)/2


###################################################
### code chunk number 6: ex_gs_spatvar.Rnw:120-129
###################################################
(gamma <- 0.5 * (meuse$zinc.l[1] - meuse$zinc.l[2])^2)
dim(coordinates(meuse))
head(coordinates(meuse)[,1])
head(coordinates(meuse)[,2])
coordinates(meuse)[1,]
coordinates(meuse)[2,]
coordinates(meuse)[1,1]
coordinates(meuse)[1,2]
(sep <- sqrt((coordinates(meuse)[1,1] - coordinates(meuse)[2,1])^2 + (coordinates(meuse)[1,2] - coordinates(meuse)[2,2])^2))


###################################################
### code chunk number 7: ex_gs_spatvar.Rnw:161-163
###################################################
(v <- variogram(zinc.l ~ 1, meuse, cutoff=1300, width=90))
print(plot(v, plot.numbers=T))


###################################################
### code chunk number 8: ex_gs_spatvar.Rnw:200-201
###################################################
print(show.vgms())


###################################################
### code chunk number 9: ex_gs_spatvar.Rnw:244-246
###################################################
vm <- vgm(psill=0.12,model="Sph",range=850,nugget=0.01)
print(plot(v, pl=T, model=vm))


###################################################
### code chunk number 10: ex_gs_spatvar.Rnw:254-256
###################################################
(vmf <- fit.variogram(v, vm))
print(plot(v, pl=T, model=vmf))



# Creates a quasi-regular pattern of simulated from the cell centres of a 
# discrete global grid.
#
# Author: Luís de Sousa luis (dot) desousa (at) isric (dot) org
# Author: Laura Poggio laura (dot) poggio (at) isric (dot) org
# Date: 12-03-2019
# 
# Copyright (c) 2019 ISRIC - World Soil Information. All rights reserved.
# Any use of this software constitutes full acceptance of all terms of the
# document licence.
# SPDX-License-Identifier:  
###############################################################################

# Regular grid
# Mask from land use (i.e. deserts?) : maybe use : wget http://due.esrin.esa.int/files/Globcover2009_V2.3_Global_.zip
# select grid points in the mask
# create profiles : 100% sand, 0 SOC, ask pH from soil scientist?
# make sure joins are possible

library(dggridR)
library(rgrass7)

use_sp()

# Construct a grid with desired resolution
dggs <- dgconstruct(res=as.numeric(Sys.getenv("DGG_RES")))

# Sequence of cell ids
allSeqs <- seq(1, dgmaxcell(dggs))

# Obtain cell centres
cellCentres <- dgSEQNUM_to_GEO(dggs, allSeqs)

# Create data.frame with cellCentres and cell ids
df.cellCentres <- data.frame(allSeqs, cellCentres[[1]], cellCentres[[2]])
colnames(df.cellCentres) <- c("id", "lon", "lat") 

# Shift ids to avoid collision with other datasets
df.cellCentres$id <- df.cellCentres$id + as.numeric(Sys.getenv("ID_INIT_SYNTH"))

# --- Save to GRASS ---
centresWGS84 <- SpatialPointsDataFrame(
		df.cellCentres[,c("lon", "lat")], 
		as.data.frame(df.cellCentres[]),
		proj4string=CRS(Sys.getenv("WGS84")))

centresIGH <- spTransform(centresWGS84, CRS(Sys.getenv("IGH")))

# Initialise GRASS session
initGRASS(
		gisBase = Sys.getenv("GRASS_BASE"), 
		home = tempdir(), 
		gisDbase = Sys.getenv("GDIR"),
		location = Sys.getenv("GLOC"), 
		mapset = Sys.getenv("MAPSET_USER"),
		override=TRUE)

writeVECT(centresIGH, Sys.getenv("GLOBAL_MESH"), v.in.ogr_flags=c("o","overwrite"))



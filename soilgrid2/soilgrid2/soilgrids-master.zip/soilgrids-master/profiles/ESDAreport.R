#!/usr/bin/env Rscript
# Prepares a statistical analysis report for a given VOI. The analysis can be
# restricted spatially and/or by depth,
#
# Author: Luís de Sousa luis (dot) desousa (at) isric (dot) org
# Author: Laura Poggio laura (dot) poggio (at) isric (dot) org
# Date: 13-03-2020
# 
# Copyright (c) 2020 ISRIC - World Soil Information. All rights reserved.
# Any use of this software constitutes full acceptance of all terms of the
# document licence.
# SPDX-License-Identifier:  
###############################################################################

library("optparse")
library("stringr")
library(RPostgreSQL)

fileBBox <- paste0(Sys.getenv("SRCDIR"),'/profiles/obsBBox.sql')
fileCountry <- paste0(Sys.getenv("SRCDIR"),'/profiles/obsCountry.sql')

option_list = list(
    make_option(c("-v", "--voi"), type="character", default=NULL, 
              help="Variable of interest", metavar="character"),
    make_option(c("-c", "--country"), type="character", default=NULL, 
              help="Identifier of a country to analyse", metavar="character"),
    make_option(c("-a", "--attribute"), type="character", default="admin", 
              help="Column in country table in which to search for the country identifier", 
              metavar="character"),
    make_option(c("-b", "--bbox"), type="character", default=NULL, 
              help="Spatial bounding box in the format: minX,miY,maxX,maxY", metavar="character"),
    make_option(c("-d", "--depth"), type="character", default="0,200", 
              help="Depth interval to analyse in the format: top,bottom", metavar="character"),
    make_option(c("-l", "--litter"), action="store_true", default=FALSE,
              help="Include litter layers"),
    make_option(c("-o", "--outdir"), type="character", default="./",
              help="Output directory")
)
 
opt_parser = OptionParser(option_list=option_list);
opt = parse_args(opt_parser);

if (is.null(opt$voi)){
    print_help(opt_parser)
    stop("At least a variable of interest must supplied (-v)", call.=FALSE)
}


if (is.null(opt$country)) {
    query <- readChar(fileBBox, file.info(fileBBox)$size)

    if (!is.null(opt$bbox)){
        bbox <- strsplit(opt$bbox, ",")
        query <- paste0(query, " AND easting > " , bbox[[1]][1], 
                               " AND northing > ", bbox[[1]][2],
                               " AND easting < ",  bbox[[1]][3],
                               " AND northing < ", bbox[[1]][4])
    }
} else {
    if (!is.null(opt$bbox)){
        stop("Can not use bounding box and country at the same time")
    } else {
        query <- readChar(fileCountry, file.info(fileCountry)$size)
        query <- str_replace(query, "<cntr_col>", opt$attribute)
        query <- str_replace(query, "<cntr_key>", opt$country)
    }
}

if (!is.null(opt$depth)){
    depths <- strsplit(opt$depth, ",")

    query <- str_replace(query, "> 0", paste0("> ", depths[[1]][1]))
    query <- str_replace(query, "< 200", paste0("< ", depths[[1]][2]))
}

if (!opt$litter){
    query <- paste0(query, " AND litter IS FALSE")
}

query <- str_replace_all(query, "<voi>", opt$voi)
query <- str_replace_all(query, "<stream>", Sys.getenv("DATA_STREAMS"))
query <- paste0(query, ";")

print("The query:")
cat(query)
print("")

connPg <-  dbConnect(PostgreSQL(), 
		host=Sys.getenv("PG_HOST"), 
		port=Sys.getenv("PG_PORT"), 
		user=Sys.getenv("PG_USER"), 
		password=Sys.getenv("PG_PASS"), 
		dbname=Sys.getenv("PG_DB"))

df=dbGetQuery(connPg, query)

saveRDS(df,paste0(opt$outdir,"df_esda.RDS"))

print(head(df))

source(paste0(Sys.getenv("SRCDIR"),"/profiles/ESDAreport_plots.R"))

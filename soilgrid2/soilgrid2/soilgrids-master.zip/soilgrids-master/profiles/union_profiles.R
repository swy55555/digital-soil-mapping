# Binds together the three sources of profile locations:
# - WoSIS
# - Rapid Stream
# - Synthetic profiles
#
# Author: Luís de Sousa luis (dot) desousa (at) isric (dot) org
# Author: Laura Poggio laura (dot) poggio (at) isric (dot) org
# Date: 01-04-2019
# 
# Copyright (c) 2019 ISRIC - World Soil Information. All rights reserved.
# Any use of this software constitutes full acceptance of all terms of the
# document licence.
# SPDX-License-Identifier:  
###############################################################################

library(rgrass7)
library(RPostgreSQL)

use_sp()

query <- paste0(
		"SELECT id, id_dataset, ",
		       "ST_X(geom_marinus) AS lon, ",
			   "ST_Y(geom_marinus) AS lat, ",
			   "ST_X(geom) AS easting, ",
			   "ST_Y(geom) AS northing ",
		"  FROM ",Sys.getenv("PG_SCHEMA_OBS"),".",Sys.getenv("REL_PROFILE")," where id_stream=",Sys.getenv("DATA_STREAMS"))
		
drv <- dbDriver("PostgreSQL")
# creates a connection to the postgres database
# note that "con" will be used later in each connection to the database
conn <- dbConnect(
		drv, 
		dbname = Sys.getenv("PG_DB"),
		host = Sys.getenv("PG_HOST"), 
		port = Sys.getenv("PG_PORT"),
		user = Sys.getenv("PG_USER"), 
		password = Sys.getenv("PG_PASS"))

profiles_raw <- dbGetQuery(conn, query)
profiles_raw_sp <- SpatialPointsDataFrame(
		profiles_raw[,c("easting", "northing")], 
		profiles_raw[,c("id","id_dataset")])
		
dbDisconnect(conn)

# Initialise GRASS session
initGRASS(
		gisBase = Sys.getenv("GRASS_BASE"), 
		home = tempdir(), 
		gisDbase = Sys.getenv("GDIR"),
		location = Sys.getenv("GLOC"), 
		mapset = Sys.getenv("MAPSET_USER"),
		override=TRUE)
		
conn <- dbConnect(
		drv, 
		dbname = "grass",
		host = Sys.getenv("PG_HOST"), 
		port = Sys.getenv("PG_PORT"),
		user = Sys.getenv("PG_USER"), 
		password = Sys.getenv("PG_PASS"))


# --- Load synthetic profiles locations ---

profiles_wise <- readVECT(Sys.getenv("WISE_PROFILES"))
table_wise <- dbGetQuery(conn, paste0("select * from ",Sys.getenv("WISE_PROFILES")))
profiles_wise <- profiles_wise[,c("id")]
profiles_wise$id = table_wise$id
profiles_wise$id_dataset <- 1000

profiles_synth <- readVECT(Sys.getenv("SYNTH_VEC_PROFS"))
table_synth <- dbGetQuery(conn, paste0("select * from ",Sys.getenv("SYNTH_VEC_PROFS")))
profiles_synth <- profiles_synth[,c("id")]
profiles_synth$id = table_synth$id
profiles_synth$id_dataset <- 1000

proj4string(profiles_raw_sp)=proj4string(profiles_wise)

profiles <- rbind(profiles_raw_sp, profiles_synth, profiles_wise)
row.names(profiles)=profiles$id
names(profiles)=c("id_profile","id_dataset")

# --- Save to GRASS ---
writeVECT(profiles, Sys.getenv("PROFILES_UNION"), v.in.ogr_flags=c("o","overwrite"))
dbDisconnect(conn)


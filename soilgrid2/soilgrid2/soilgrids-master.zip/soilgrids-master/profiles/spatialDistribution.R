# This programme assesses the spatial distribution of observations per 
# variable. At this stage this is not yet made on a 3D basis.
#
# Author: Luís de Sousa luis (dot) desousa (at) isric (dot) org
# Author: Laura Poggio laura (dot) poggio (at) isric (dot) org
# Date: 18-02-2019
# 
# Copyright (c) 2019 ISRIC - World Soil Information. All rights reserved.
# Any use of this software constitutes full acceptance of all terms of the
# document licence.
# SPDX-License-Identifier:  
###############################################################################

require("RPostgreSQL")
library(dggridR)
library(ggplot2)
library(fBasics)
library(plyr)
library(knitr)

source(paste0(Sys.getenv("SRCDIR"),"/common/depths.R"))

depths <- getDepthsMidPoints()

DGGres <- as.numeric(Sys.getenv("DGG_RES"))
DGGaperture <- 3

# This is an approximate number
numCellsLand <- 0.28 * (30*DGGaperture) ^ (DGGres-1)

# Lock-up table for RS variable names
RSvariables <- c(
		"crfvol",
		"sndppt",
		"sltppt",
		"clyppt",
		"bld",
		"phihox",
		"phikcl",
		"orcdrc",
		"cecsum",
		"phical")

names(RSvariables) <- c(
		"CFVO",
		"SAND",
		"SILT",
		"CLAY",
		"BDFI33",
		"PHAQ",
		"PHKC",
		"ORGC",
		"ECEC",
		"PHCA")

initCounts <- function()
{
	counts <<- data.frame(
		attribute=character(), 
		depth=integer(),
		profiles=integer(), 
		cells=integer(), 
		stringsAsFactors=FALSE)
}

initProfsDist <- function()
{
	profsDist <<- data.frame(
			attribute=character(), 
			minimum=numeric(),
			maximum=numeric(), 
			mean=numeric(), 
			median=numeric(),
			q0.05=numeric(),
			q0.95=numeric(),
			stdev=numeric(),
			stringsAsFactors=FALSE)
}

computeVariable <- function(variable, depth)
{
	message(paste0("Processing variable: ", variable, " at depth: ", depth))
	query <- paste0(
			"SELECT DISTINCT profile_id, longitude, latitude ",
			"  FROM sg250m.v_wosis_layer_profile ",
			" WHERE ",tolower(variable),"_value_avg IS NOT NULL")
	
	if(!is.na(depth))
	{
		query <- paste0(query,
			"   AND upper_depth <= ",depth,
			"   AND lower_depth >= ",depth)
	}

	if(!is.na(RSvariables[variable]))
	{
		query <- paste0(query,
			" UNION ",
			"SELECT DISTINCT p.profile_id, p.lonwgs84 AS longitude, p.latwgs84 AS latitude",
			"  FROM sg250m.rs_201901_profiles p, ",
			"		sg250m.rs_201901_layers l ",
			" WHERE p.profile_id = l.profile_id",
			"   AND ",RSvariables[variable]," IS NOT NULL ")
	
		if(!is.na(depth))
		{
			query <- paste0(query,
					"   AND uhdicm <= ",depth,
					"   AND lhdicm >= ",depth)
		}
	}
	query <- paste0(query, ";")
			
	df <- dbGetQuery(conn, query)
	
	ncells <- 0
	if(nrow(df) > 0)
	{
		# Use DGG 
		df$cell <- dgGEO_to_SEQNUM(dggs, df$longitude, df$latitude)$seqnum	
		cells <- unique(df$cell)
		ncells <- length(cells)
	}
	
	counts[nrow(counts) + 1,] <<- list(variable, depth, nrow(df), ncells)
	
	# Statistics of profiles per cell
	if(is.na(depth) && ncells > 0)
	{
		df.cells <- data.frame(cells)
		names(df.cells) <- c("cell")
		df.cells$n_profs <- 0
		df.cells$n_profs <- lapply(df.cells$cell, function(x) {df.cells[df.cells$cell==x,]$n_profs <- nrow(df[df$cell==x,])})
		stats <- basicStats(as.numeric(df.cells$n_profs))
		profsDist[nrow(profsDist) + 1,] <<- list(
				variable, 
				stats["Minimum",], 
				stats["Maximum",], 
				stats["Mean",], 
				stats["Median",], 
				stats["1. Quartile",], 
				stats["3. Quartile",], 
				stats["Stdev",])
	}
	
}

computeVarByDepth <- function(variable)
{
	initCounts()
	computeVariable(variable, depth=depths[1])
	computeVariable(variable, depth=depths[2])
	computeVariable(variable, depth=depths[3])
	computeVariable(variable, depth=depths[4])
	computeVariable(variable, depth=depths[5])
	computeVariable(variable, depth=depths[6])
	
	pdf(paste0(Sys.getenv("OUTDIR"),variable,"_depth_dist.pdf"))
	counts$percent <- counts$cells / numCellsLand * 100
	plot <- ggplot(counts, aes(depth, percent)) +
			geom_col()
	print(plot)
	dev.off()
}

# loads the PostgreSQL driver
drv <- dbDriver("PostgreSQL")
# creates a connection to the postgres database
# note that "conn" will be used later in each connection to the database
conn <- dbConnect(
		drv, 
		dbname = Sys.getenv("PG_DB"),
		host = Sys.getenv("PG_HOST"), 
		port = Sys.getenv("PG_PORT"),
		user = Sys.getenv("PG_USER"), 
		password = Sys.getenv("PG_PASS"))

# Construct a grid of the desired resolution
dggs <- dgconstruct(res=DGGres)

# Select all attributes codes
attributes <- dbGetQuery(conn, paste0(
				"SELECT code FROM sg250m.wosis_201901_attributes ", 
                "WHERE type LIKE 'Horizon'"));

initCounts()
initProfsDist()
lapply(attributes$code, computeVariable, depth=NA)

# Join data.frames and create table
countsFull <- join(counts[c("attribute", "profiles", "cells")], profsDist, type="left", by="attribute")
countsFull <- countsFull[with(countsFull, order(-cells)), ]
sink(file=paste0(Sys.getenv("OUTDIR"),"SpatialDistRes",DGGres,".md"))
kable(countsFull, format = "markdown")
sink()

# Show it
counts$percent <- counts$cells / numCellsLand * 100
pdf(paste0(Sys.getenv("OUTDIR"),"spatial_dist.pdf"))
plot <- ggplot(counts, aes(attribute, percent)) +
		geom_col() + 
		theme(axis.text.x = element_text(angle = 90, hjust = 1))
print(plot)
dev.off()

# Show how the highest vary with depth
highest <- counts[counts$percent > 30,]
lapply(highest$attribute, computeVarByDepth)

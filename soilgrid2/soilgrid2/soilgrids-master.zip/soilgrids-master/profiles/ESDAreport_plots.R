library(tidyverse)

voi=opt$voi
outdir=opt$oudir

source(paste0(Sys.getenv("SRCDIR"),"/common/ggplot_conf.R"))
db0=readRDS("df_esda.RDS")    

db = db0 %>% mutate(stdepth = case_when(
                            depth_midpoint <=  5 ~ 5,
                            depth_midpoint > 5 & depth_midpoint <= 15 ~ 15,
                            depth_midpoint > 15 & depth_midpoint <= 30 ~ 30,
                            depth_midpoint > 30 & depth_midpoint <= 60 ~ 60,
                            depth_midpoint > 60 & depth_midpoint <= 100 ~ 100,
                            depth_midpoint > 100 & depth_midpoint <= 200 ~ 200,
                            depth_midpoint > 200 | is.na(depth_midpoint) ~ 201,
                            ))

gg=ggplot(db, aes(x=get(voi))) + geom_histogram(position="identity", size = 1) + facet_wrap(.~ stdepth, ncol = 3)
gg=gg+thggp_line + thggtitle + xlab("") + ylab("") + guides(linetype = "none")

png(paste0(outdir,"test_hist.png"), width = 3800, height = 2000, units = 'px', res = 300)
    print(gg)
dev.off()


dfk = db %>% group_by(stdepth) %>% summarize(
            min=min(get(voi), na.rm=T),
            max=max(get(voi), na.rm=T),
            mean=mean(get(voi), na.rm=T),
            median=median(get(voi), na.rm=T),
            q25=quantile(get(voi), probs=0.25, na.rm=T),
            q75=quantile(get(voi), probs=0.75, na.rm=T),
            sd=sd(get(voi), na.rm=T),
            skewness=e1071::skewness(get(voi), na.rm=T),
            kurtosis=e1071::kurtosis(get(voi), na.rm=T)
            )

kableExtra::kable(dfk, "markdown", digits=3)

write.csv(dfk,file=paste0(outdir,"summary_depth_query.csv"))

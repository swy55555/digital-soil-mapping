list.of.packages <- c(
    "tidyverse", 
    "ranger",
    "caret",
    "rgrass7",
    "dggridR",
    "sp",
    "sf",
    "Metrics",
    "verification",
    "DescTools",
    "Compositional",
    "IDPmisc")

new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)

install.packages("BiocManager")
BiocManager::install(c("impute", "preprocessCore", "GO.db", "AnnotationDbi"), update=FALSE)
install.packages("WGCNA")

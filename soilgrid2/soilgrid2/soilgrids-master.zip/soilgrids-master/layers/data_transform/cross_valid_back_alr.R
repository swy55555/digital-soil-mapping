library(tidyverse)
library(ranger)
library(pbapply)

args = commandArgs(TRUE)

if (length(args)==0) {
args=c("1") # 
} 

f=as.numeric(args[1])
ntrees=as.numeric(unlist(strsplit(Sys.getenv("NTREE"),",")))
mtrys=as.numeric(unlist(strsplit(Sys.getenv("MTRY"),",")))

quants=as.numeric(unlist(strsplit(Sys.getenv("QUANTS"),",")))
vois=unlist(strsplit(Sys.getenv("VOI"),","))

alr1=data.frame(readRDS(paste0(Sys.getenv("CVDIR"), "CV_TreesPreds_alr1_fold_",f,"_mtry_",mtrys[1],"_ntree_",ntrees[1],".RDS")))
alr2=data.frame(readRDS(paste0(Sys.getenv("CVDIR"), "CV_TreesPreds_alr2_fold_",f,"_mtry_",mtrys[2],"_ntree_",ntrees[2],".RDS")))

df.pred=readRDS(paste0(Sys.getenv("CVDIR"),"CV_predictions_alr1_fold_",f,"_mtry_",mtrys[1],"_ntree_",ntrees[1],".RDS"))
df.pred=df.pred[,grep("alr",names(df.pred),invert=T)]

source(paste0(Sys.getenv("SRCDIR"),"/layers/data_transform/functions_alr.R"))

comb_cols=expand.grid(names(alr1),names(alr2))
idxs=readRDS(paste0(Sys.getenv("PARAMDIR"),"index_trees_alr.RDS"))

system.time({inv_pred=lapply(idxs, function(x) fun_invalrCV(x,comb_cols,alr1,alr2))})
df_invpred=lapply(1:3,function(x){fun_invtext(x,inv_pred,vois,quants)})
names(df_invpred)=vois

df_pred=cbind(df.pred,do.call(cbind,df_invpred))
names(df_pred)=gsub("\\.","_",names(df_pred))
system.time({saveRDS(df_pred, file=paste0(Sys.getenv("CVDIR"), "CV_predictions_text_fold_",f,"_backTransform.RDS"))}) # 



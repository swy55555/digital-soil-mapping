tbl0[,Sys.getenv("VOITR")]=log(tbl0[,Sys.getenv("VOI")]+0.0001)

library(tidyverse)

args = commandArgs(TRUE)
if (length(args)==0) {
args=c(Sys.getenv("VOI")) # 
}


fldsrc=Sys.getenv("SRCDIR")
source(paste0(fldsrc,"/common/ggplot_conf.R"))
source(paste0(Sys.getenv("SRCDIR"),"/common/fun_metrics.R"))
svar=args[1]

df_values=readRDS(paste0(Sys.getenv("CVDIR"), "CV_predictions_append_",svar,Sys.getenv("TRANSFORM"),".RDS"))

df_values_back=df_values %>% mutate(soc_mean=exp(soclog_mean+0.5*var(soclog_mean)), soc_quant_0.05=exp(soclog_quant_0.05), soc_quant_0.5=exp(soclog_quant_0.5), soc_quant_0.95=exp(soclog_quant_0.95))

saveRDS(df_values_back, paste0(Sys.getenv("CVDIR"), "CV_predictions_append_",svar,".RDS"))

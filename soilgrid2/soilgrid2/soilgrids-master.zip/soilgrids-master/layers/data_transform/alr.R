library(Compositional)

df.alr=tbl0[,c("id_profile",unlist(strsplit(Sys.getenv("VOI"),",")))]

alr_comp=as.data.frame(alr(as.matrix(df.alr[,unlist(strsplit(Sys.getenv("VOI"),","))])))
names(alr_comp)=paste0("alr",1:ncol(alr_comp))

tbl=IDPmisc::NaRV.omit(cbind(tbl0,alr_comp))
tbl0=tbl

source(paste0(Sys.getenv("SRCDIR"),"/layers/data_transform/functions_alr.R"))
source(paste0(Sys.getenv("SRCDIR"),"/predictions/","/write_raster.R"))

vois=unlist(strsplit(Sys.getenv("VOI"),","))

comb_cols=expand.grid(colnames(pred_alr1[[1]]$predictions),colnames(pred_alr2[[1]]$predictions))
# idxs=sample(1:nrow(comb_cols),(nrow(comb_cols)*0.01))
idxs=readRDS(paste0(Sys.getenv("PARAMDIR"),"index_trees_alr.RDS"))



lapply(1:length(depths_dirs),function(D){

    message(paste0("Back-transformation for depth ",depths_dirs[D]))
    system.time({inv_pred=lapply(idxs, function(x) fun_invalr(x,comb_cols,pred_alr1[[D]],pred_alr2[[D]]))})

#     message(paste0("Quantiles for depth ",depths_dirs[D]))
#     df_invpred=lapply(1:length(vois), function(x) {fun_invtext(x,inv_pred,vois,quants)})

    message(paste0("Quantiles and Writing rasters for depth ",depths_dirs[D]))
    lapply(1:3,function(x){
        df_invpred=fun_invtext(x,inv_pred,vois,quants)
            fun_write_rst(
                coords=df_pred[,c("x","y")],
                predQuants=df_invpred,
                crsrst=crs_rst,
                tile=tile,
                depthsDir=depths_dirs[D],
                VOI=vois[x])
            })

})

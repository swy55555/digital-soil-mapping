library(Compositional)
library(data.table)

# ### function to calculate inverse alr
# Inputs: 
#   x: row number with the ombinations of columns
#   COMBS: the combinations of columns

alrinv1 <- function (y){
    x=matrix(1,nrow=dim(y)[1],ncol=3)
    x[,2:3]=exp(y)
    x/rowSums(x)
#     print(c(pryr::address(x),pryr::refs(x)))
}

fun_invalr=function(x,COMBS,ALR1,ALR2){

    if(ALR1$num.samples!=ALR2$num.samples){
        message(paste0("different number of pixels in the components for tile ",tile))
        dt_alr1=setDT(data.frame(ALR1[cbind("x","y","predictions")]))
        dt_alr2=setDT(data.frame(ALR2[cbind("x","y","predictions")]))

        dt_alr=dt_alr1[dt_alr2, on = c(x="x", y="y")]
# # #         print(names(dt_alr)[grep(paste0("^i\\.predictions\\.",unlist(COMBS[x,][1]),"$"),names(dt_alr))])
# # #         print(names(dt_alr)[grep(paste0("^i\\.predictions\\.",unlist(COMBS[x,][2]),"$"),names(dt_alr))])

        calr1=names(dt_alr)[grep(paste0("^predictions\\.",unlist(COMBS[x,][1]),"$"),names(dt_alr))]
        calr2=names(dt_alr)[grep(paste0("^i.predictions\\.",unlist(COMBS[x,][2]),"$"),names(dt_alr))]
       
        alr1=dt_alr[,..calr1]    
        alr2=dt_alr[,..calr2]    
        cc=alrinv(as.matrix(cbind(alr1,alr2)))
    } else {
        cc=alrinv(cbind(ALR1$predictions[,unlist(COMBS[x,][1])],ALR2$predictions[,unlist(COMBS[x,][2])]))
    }
}


fun_invalrCV=function(x,COMBS,ALR1,ALR2){

    if(nrow(alr1)!=nrow(alr2)){
        message("problem")
    } else {
        cc=alrinv(cbind(ALR1[,unlist(COMBS[x,][1])],ALR2[,unlist(COMBS[x,][2])]))
    }
}


# ### function to calculate quantiles after inverse alr
# Inputs:
#   V: texture component, e.g. sand
#   INPUT: the invalr transformation of the predictions
#   VOIS: all texture components (e.g sand, silt, clay) [environmental variable]
#   QUANTS: quantiles  [environmental variable]

fun_invtext = function(V,INPUT,VOIS,QUANTS){
component=do.call(cbind, lapply(INPUT, function(x) x[,V]))
qq=lapply(1:length(QUANTS),function(x){WGCNA::rowQuantileC(component,quants[x])})
# # # pred_quants <- data.frame(t(apply(component, 1, quantile, quants, na.rm=TRUE))); names(pred_quants)=paste0(VOIS[V],"_Q",QUANTS)
# pred_quants <- as.data.frame(do.call(cbind,qq)); names(pred_quants)=paste0("Q",QUANTS)
# pred_mean <- data.frame((apply(component, 1, mean, na.rm=TRUE))); names(pred_mean)=paste0("mean")
pred_df=data.frame(cbind(do.call(cbind,qq),apply(component, 1, mean, na.rm=TRUE))); names(pred_df)=c(paste0("Q",QUANTS),paste0("mean"))
return(pred_df)
}


# ### function to calculate quantiles after inverse alr (for predictions)
# Inputs:
#   x: depth layer
#   PRED1:
#   PRED2:
#   VOIS: all texture components (e.g sand, silt, clay) [environmental variable]
#   QUANTS: quantiles  [environmental variable]


backtransform_alr_pred=function(x,PRED1,PRED2,IDXS,COMBS,VOIS,QUANTS,CELL){
alr1=PRED1[[x]]$predictions
alr2=PRED2[[x]]$predictions

# comb_cols=expand.grid(colnames(alr1),colnames(alr2))
inv_pred=lapply(IDXS, function(x) fun_invalr(x,COMBS,alr1,alr2,CELL))
df_invpred=lapply(1:length(VOIS), function(x) {fun_invtext(x,inv_pred,VOIS,QUANTS)})
}

# # # fun_invalr=function(x,COMBS,ALR1,ALR2,CELL){
# # # trees=COMBS[x,]
# # # tree1=as.character(unlist(trees[1]))
# # # tree2=as.character(unlist(trees[2]))
# # # cc=alrinv1(cbind(ALR1[CELL,tree1],ALR2[CELL,tree2]))
# # # }

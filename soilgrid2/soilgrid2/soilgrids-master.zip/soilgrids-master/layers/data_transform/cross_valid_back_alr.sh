for (( F=1; F<=10; F++ )) do
    $R_EXEC  $SRCDIR/layers/data_transform/cross_valid_back_alr.R $F
done

$R_EXEC  $SRCDIR/layers/data_transform/cross_valid_back_alr_append.R $VOI

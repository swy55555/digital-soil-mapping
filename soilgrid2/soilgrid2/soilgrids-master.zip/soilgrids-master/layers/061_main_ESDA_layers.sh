# r script

# NOTE: This may require a loop through the variables of interest (if back-transformed)
$R_EXEC $SRCDIR/layers/esda.R

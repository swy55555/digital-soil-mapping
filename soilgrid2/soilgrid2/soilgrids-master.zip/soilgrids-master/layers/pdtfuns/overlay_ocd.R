# ### Create file with coordinates to be used in GDAL
tbl0=readRDS(paste0(Sys.getenv("MODDIR"), "data_table_pdtf_ocd.RDS"))
tbl_coords=tbl0[,c("id_profile","x","y")]
tbl_coords=tbl_coords[!duplicated(tbl_coords$id_profile),]

# ### Call a bash script to do overlay with CFVO
dir.create(paste0(Sys.getenv("MODDIR"),"ptf"), recursive=TRUE)
write.csv(tbl_coords, paste0(Sys.getenv("MODDIR"),"ptf/","coordinates.csv"), quote=F,row.names=F)

system(paste0("source ",Sys.getenv("SRCDIR"),"layers/pdtfuns/overlay_ocd.sh"))

# ### Read-in the results of the overlay and join with table with data
tbl_join=read.csv(paste0(Sys.getenv("MODDIR"),"ptf/","coordinates_cfvo.csv"))
tbl_join[ tbl_join < 0 ] <- NA

# # # tbl_join_m=reshape2::melt(tbl_join,c("id_profile","x","y"))
# # # 
# # # tbl_join_m$d=gsub("cm","",unlist(sapply(strsplit(as.character(tbl_join_m$variable),"_"),"[",2)))
# # # dd=strsplit(tbl_join_m$d,"\\.")
# # # 
# # # tbl_join_m$cfvo_top=as.numeric(sapply(dd,"[",1))
# # # tbl_join_m$cfvo_bottom=as.numeric(sapply(dd,"[",2))
# # # tbl_join_m$value=ifelse(tbl_join_m$value<0,NA,tbl_join_m$value)
# # # tbl_join_m$value=ifelse(tbl_join_m$value>10000,NA,tbl_join_m$value)

tbl=dplyr::inner_join(tbl0,tbl_join, by="id_profile") 
tbl=tbl[,grep("\\.y$",names(tbl),invert=T)]
names(tbl)=gsub("\\.x$","",names(tbl))

# ### Calculate CFVO correction and final OCD 
library(tidyverse)

tbl1=tbl %>% mutate(cfdpt = case_when(
                        depth <=  5 ~ 5,
                        depth > 5 & depth <= 15 ~ 15,
                        depth > 15 & depth <= 30 ~ 30,
                        depth > 30 & depth <= 60 ~ 60,
                        depth > 60 & depth <= 100 ~ 100,
                        depth > 100 & depth <= 200 ~ 200,
                        depth > 200 | is.na(depth) ~ 0,
                        ))
tbl1$cfdpt=ifelse(tbl1$cfdpt==0,NA,tbl1$cfdpt)

tbl1=tbl1 %>% mutate(cfvomix=
            ifelse(is.na(cfvo) & cfdpt ==5 ,cfvo_0.5cm_Q0.5/100,
            ifelse(is.na(cfvo) & cfdpt==15,cfvo_0.5cm_Q0.5/1000, 
            ifelse(is.na(cfvo) & cfdpt==30,cfvo_15.30cm_Q0.5/100,
            ifelse(is.na(cfvo) & cfdpt==60,cfvo_30.60cm_Q0.5/100,
            ifelse(is.na(cfvo) & cfdpt==100,cfvo_60.100cm_Q0.5/100,
            ifelse(is.na(cfvo) & cfdpt==200,cfvo_100.200cm_Q0.5/100,
            ifelse(!is.na(cfvo),cfvo,NA ))))))) )

tbl2= tbl1 %>% mutate(ocd=ocd_ptf*(1-(cfvomix/100))) %>% mutate(ocd=ifelse(ocd>150,NA,ocd))

drop_cols=c("soc","phh2o","bdod","sand","silt","clay","cfvo","soc_cl","ocd0","soc_clf","ocd_ptf","cfdpt","cfvomix",names(tbl2)[grep("cfvo_",names(tbl2))])
tbl3=tbl2%>%dplyr::select(-one_of(drop_cols))

source(paste0(Sys.getenv("SRCDIR"),"common/reg_matrix.R"))
save_reg_matrix(tbl3)

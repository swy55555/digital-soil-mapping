library(tidyverse)
library(ranger)

tbl0=readRDS(paste0(Sys.getenv("MODDIR"), 
        "data_table_",gsub(",","_",Sys.getenv("VOI")),".RDS"))

tbl0$soc_cl=ifelse(tbl0$soc<=20,1,ifelse(tbl0$soc>20 & tbl0$soc<=50,2,ifelse(tbl0$soc>50 & tbl0$soc<=100,3,ifelse(tbl0$soc>100 & tbl0$soc<=200,4,5))))

tbl1=tbl0 %>% filter(complete.cases(soc)) %>% filter(bdod<=2 | is.na(bdod))
tbl1$ocd0=(tbl1$soc+0.01)*tbl1$bdod
tbl1$soc_clf=as.factor(tbl1$soc_cl)

tbl2 = tbl1 %>% filter(complete.cases(sand,silt,clay,phh2o,soc))
tbl3 = tbl2 %>% filter(complete.cases(bdod))

mod_rf=ranger(log(ocd0)~sand+silt+clay+phh2o+depth+soc_clf,data=tbl3, num.threads=2, importance="impurity", quantreg=TRUE)
rf_pred=predict(mod_rf,tbl2, num.threads=2, type="quantiles", quantiles = c(0.05, 0.5, 0.95))

var_pred=((rf_pred$predictions[,3]-rf_pred$predictions[,1])/(2*1.64))^2

tbl2$ocd_ptf=exp(rf_pred$predictions[,2]+(0.5*var_pred))
# exp[pred+0.5*var]
# var=((q95-q5)/(2*1.64))^2

tbl=tbl2 %>% filter((tbl2$ocd_ptf/(tbl2$soc+0.01))<=2.1)

saveRDS(tbl, file=paste0(Sys.getenv("MODDIR"), 
        "data_table_pdtf_",gsub(",","_",Sys.getenv("VOI")),".RDS"))

# # # tbl2b=tbl2 %>% filter((tbl2$ocd0/(tbl2$soc+0.01))<=2.1)
# # # tbl2b$bdrt0=tbl2b$ocd0/(tbl2b$soc+0.01)
# # # tbl2b$bdrt=tbl2b$ocd_ptf/(tbl2b$soc+0.01)
# # # 
# # # x11()
# # # par(mfrow=c(1,2))
# # # plot(tbl2b$bdrt0,tbl2b$soc, pch=19)
# # # plot(tbl2b$bdrt,tbl2b$soc, pch=19)
# # # plot(tbl2b$x,tbl2b$y,pch=19)

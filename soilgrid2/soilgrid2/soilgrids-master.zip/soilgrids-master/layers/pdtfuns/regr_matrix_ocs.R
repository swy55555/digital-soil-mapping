library(tidyverse)
library(RPostgreSQL)

args = commandArgs(TRUE)
runocd=args[1]
# runocd="ranger_RUN03"

tbl0=readRDS(paste0(Sys.getenv("OUTDIR"),"ocd/",runocd,"/","regr_matrix_ocd.RDS"))

# Select relevant depth and calculate thickness of the horizon/observation 

dptint=as.numeric(unlist(strsplit(Sys.getenv("DPTINT"),",")))
tbl1 = tbl0 %>% filter(top >= dptint[1] & bottom <= dptint[length(dptint)]) %>% mutate(thick=bottom-top)

if(length(dptint)==2){
    tbl2= tbl1 %>% group_by(id_profile) %>% summarize(ocs=sum(ocd*(thick/10))/10 )
    names(tbl2)[grep("ocs",names(tbl2))]=paste0("ocs")
} else {

tbl1 = tbl1 %>% mutate(dptint = case_when(
                depth <=  30 ~ 30,
                depth > 30 & depth <= 100 ~ 100,
                depth > 100 & depth <= 200 ~ 200,
                depth > 200 ~ NA_real_,
                ))
tbl2= tbl1 %>% group_by(id_profile,dptint) %>% summarize(ocs=sum(ocd*(thick/10))/10 )
names(tbl2)[grep("dptint", names(tbl2))]=Sys.getenv("DEPTH_COL")

}

# ### Units analysis
# ocd = g/kg*kg/dm^3 --> g/dm^3
# thickness in dm --> thick/10

# ocs=g/dm^3 * dm --> g/dm^2 
# ocs in kg/m^2 by dividing the row above by 10

# ### Join with covariates
connGRASS = dbConnect(PostgreSQL(), 
		host=Sys.getenv("PG_HOST"), 
		port=Sys.getenv("PG_PORT"), 
		user=Sys.getenv("PG_USER"), 
		password=Sys.getenv("PG_PASS"), 
		dbname=Sys.getenv("PG_DB_GRASS"))
message("Reading tables from GRASS into R...")
tbl.loc=dbReadTable(connGRASS, Sys.getenv("PROFILES_COVS"), 
					schema=Sys.getenv("MAPSET_USER")) 
tbl.fld=dbReadTable(connGRASS, Sys.getenv("PROFILES_FOLD"), 
					schema=Sys.getenv("MAPSET_USER"))

tbl.prof=full_join(tbl.loc,tbl.fld, by="id_profile")
tbl=inner_join(tbl.prof,tbl2, by="id_profile") 
tbl=tbl[,grep("\\.y$",names(tbl),invert=T)]
names(tbl)=gsub("\\.x$","",names(tbl))

# tblw=tbl%>%filter(id_profile>=7000000)

source(paste0(Sys.getenv("SRCDIR"),"common/reg_matrix.R"))
save_reg_matrix(tbl)

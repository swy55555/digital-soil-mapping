library(tidyverse)

source(paste0(Sys.getenv("SRCDIR"),"common/reg_matrix.R"))

tbl0 <- load_reg_matrix()

source(paste0(Sys.getenv("SRCDIR"),"layers/data_transform/",Sys.getenv("TRANSFORM"),".R"))

save_reg_matrix(tbl0)


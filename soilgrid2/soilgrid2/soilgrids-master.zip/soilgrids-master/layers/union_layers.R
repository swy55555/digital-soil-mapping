# Binds together the three sources of profiles layers:
# - WoSIS
# - Rapid Stream
# - Synthetic profiles
# These layers are read from Postgres and saved as a regression matrix.
#
# Author: Luís de Sousa luis (dot) desousa (at) isric (dot) org
# Author: Laura Poggio laura (dot) poggio (at) isric (dot) org
# Date: 03-04-2019
# 
# Copyright (c) 2019 ISRIC - World Soil Information. All rights reserved.
# Any use of this software constitutes full acceptance of all terms of the
# document licence.
# SPDX-License-Identifier:  
###############################################################################

library(RPostgreSQL)
library(tidyverse)

source(paste0(Sys.getenv("SRCDIR"),"common/reg_matrix.R"))

pair_fields <- function(fields_sg, fields_db, prefix)
{
	res <- ""
	for (i in 1:length(fields_sg)) 
		res <- paste0(res, prefix, fields_db[i]," AS ",fields_sg[i], ", ")
	return(res)
}

not_null_restric <- function(fields_db, prefix)
{
	res <- "("
	for (i in 1:length(fields_db)) 
	{
		if(nchar(res) > 1) res <- paste0(res, " OR ")
		res <- paste0(res, prefix, fields_db[i]," IS NOT NULL ")
	}
		
	return(paste0(res,")"))
}

# Unbundle variable names
vois       <- unlist(strsplit(Sys.getenv("VOI"),","))
vois_wise  <- unlist(strsplit(Sys.getenv("WISE_VOI"),","))

rel_layer <- paste0(Sys.getenv("PG_SCHEMA_OBS"), ".", Sys.getenv("REL_LAYER"))
rel_profile <- paste0(Sys.getenv("PG_SCHEMA_OBS"), ".", Sys.getenv("REL_PROFILE"))

# Booleans are different between SQLite and Postgres
db_true <- Sys.getenv("DB_TRUE")

if(Sys.getenv("USE_LITTER")) { # Use all layers

	query <- paste0(
		"SELECT l.id_profile AS id_profile,                         ",
		        pair_fields(vois, vois, "l."),
		"	    l.top AS top,                                   ",
		"       l.bottom AS bottom                                  ",
		"  FROM ", rel_layer, " l",
		" WHERE ", not_null_restric(vois, "l."),
		"   AND l.id_profile IN                                     ",
		"      (SELECT id                                           ",
	        "         FROM ", rel_profile,
	        "        WHERE id_stream IN (", Sys.getenv("DATA_STREAMS"),"))")

} else { # Exclude litter layers adjusting depth intervals
	
	query <- paste0(
		"SELECT l.id_profile AS id_profile,                         ",
		        pair_fields(vois, vois, "l."),
		"      (l.top - ol.bottom) AS top,                          ",
		"      (l.bottom - ol.bottom) AS bottom                     ",
		"  FROM ", rel_layer, " l",
		" INNER JOIN                                                ",
		"	   (SELECT id_profile, MAX(bottom) AS bottom        ",
		"	      FROM ", rel_layer,
		"        WHERE litter = ", db_true, "                       ",
		"        GROUP BY id_profile) ol                            ",
		"    ON l.id_profile = ol.id_profile                        ",
		" WHERE litter <> ", db_true, "                             ",
		"   AND ", not_null_restric(vois, "l."),
		"   AND l.id_profile IN                                     ",
		"      (SELECT id                                           ",
	        "         FROM ", rel_profile,
	        "        WHERE id_stream IN (", Sys.getenv("DATA_STREAMS"),"))",
		" UNION ",
		"SELECT l.id_profile AS id_profile,                         ",
		        pair_fields(vois, vois, "l."),
		"	    l.top AS top,                                   ",
		"       l.bottom AS bottom                                  ",
		"  FROM ", rel_layer, " l",
		"  LEFT JOIN                                                ",
		"	 (SELECT id_profile, MAX(bottom) AS bottom          ",
		"	    FROM ", rel_layer,
		"      WHERE litter = ", db_true, "                         ",
		"      GROUP BY id_profile) ol                              ",
		"    ON l.id_profile = ol.id_profile                        ",
		" WHERE ol.id_profile IS NULL                               ",
		"   AND ", not_null_restric(vois, "l."),
		"   AND l.id_profile IN                                     ",
		"      (SELECT id                                           ",
	        "         FROM ", rel_profile,
	        "        WHERE id_stream IN (", Sys.getenv("DATA_STREAMS"),"))")
}

wiseFields <- function(vois)
{
	res <- ""
	for (i in 1:length(vois))
		res <- paste0(res, "v", i, ".", vois[i]," AS ", vois[i], ", ")
	return(res) 
}

wiseViews <- function(vois)
{
	res <- ""
	for (i in 1:length(vois)) 
		res <- paste0(res," wise.", vois[i], " v", i ,",")

	return(res)
}

wiseJoins <- function(vois)
{
	res <- ""
	for (i in 1:length(vois)) 
		res <- paste0(res," p.", Sys.getenv("WISE_ID"), " = ", 
			"(v", i ,".", Sys.getenv("WISE_ID"),") AND ")
	return(res)
}

wiseQuery <- paste0(
		"SELECT p.id as id_profile,		",
			    wiseFields(vois),
		"	    top,					",
		"	    bottom					",
		"  FROM ", Sys.getenv("MAPSET_USER"), ".", Sys.getenv("WISE_PROFILES"), " p,",
		        gsub(",$","",wiseViews(vois)),
		" WHERE ", gsub("AND $","",wiseJoins(vois)), ";"
)

# Database connections
connGRASS = dbConnect(PostgreSQL(), 
		host=Sys.getenv("PG_HOST"), 
		port=Sys.getenv("PG_PORT"), 
		user=Sys.getenv("PG_USER"), 
		password=Sys.getenv("PG_PASS"), 
		dbname=Sys.getenv("PG_DB_GRASS"))

connPg <-  dbConnect(PostgreSQL(), 
		host=Sys.getenv("PG_HOST"), 
		port=Sys.getenv("PG_PORT"), 
		user=Sys.getenv("PG_USER"), 
		password=Sys.getenv("PG_PASS"), 
		dbname=Sys.getenv("PG_DB"))
		
# Note the concatenation of schema name with table name		
message("Reading tables from GRASS into R...")
tbl.loc=dbReadTable(connGRASS, c(tolower(Sys.getenv("MAPSET_PROFS")), Sys.getenv("PROFILES_COVS")))
tbl.fld=dbReadTable(connGRASS, c(tolower(Sys.getenv("MAPSET_PROFS")), Sys.getenv("PROFILES_FOLD")))

message("Sending UNION query to database ...")
tbl.lyr=dbGetQuery(connPg, query)

message(paste0("Number of sampled layers : ", nrow(tbl.lyr)))


if(Sys.getenv("WISE_VOI")!=""){

    tbl.wise=dbGetQuery(connGRASS, wiseQuery)
    tbl.lyr=rbind(tbl.lyr, tbl.wise)
    
    message(paste0("Number of synthetic layers : ", nrow(tbl.wise)))

}

# Add Synthetic data from existing map
if(Sys.getenv("SYNTH_MAP")!=""){

	# Note that this query only functions for non-composed variables.
	# It must be re-developed if it ever comes to be necessary in such context
 	synthQuery <- paste0(
		"SELECT id as id_profile,				",
			    Sys.getenv("SYNTH_VEC_PROFS"), " AS " , Sys.getenv("VOI"), ", ",
		        Sys.getenv("SYNTH_TOP") ,"    AS top,					",
		        Sys.getenv("SYNTH_BOTTOM"), " AS bottom					",
		"  FROM ", Sys.getenv("MAPSET_USER"), ".", Sys.getenv("SYNTH_VEC_PROFS"), ";"
	)

	tbl.synth=dbGetQuery(connGRASS, synthQuery)
   tbl.lyr=rbind(tbl.lyr, tbl.synth)
    message(paste0("Number of generic synthetic layers : ", nrow(tbl.synth)))
}

tbl.prof=full_join(tbl.loc,tbl.fld, by="id_profile")
tbl=inner_join(tbl.prof,tbl.lyr, by="id_profile") 
tbl=tbl[,grep("\\.y$",names(tbl),invert=T)]
names(tbl)=gsub("\\.x$","",names(tbl))

tbl[,Sys.getenv("DEPTH_COL")]=as.numeric(tbl$bottom) + ((as.numeric(tbl$top) - as.numeric(tbl$bottom)) /2)
message(paste0("Mid-point depth of horizons calculated"))

tbl <- tbl[tbl[[Sys.getenv("DEPTH_COL")]]>0,]

message(paste0("Number of layers to be saved: ", nrow(tbl)))

dbDisconnect(connPg)
dbDisconnect(connGRASS)

message("Saving results to Postgres...")

save_reg_matrix(tbl)

message("Success: layers saved to database")		




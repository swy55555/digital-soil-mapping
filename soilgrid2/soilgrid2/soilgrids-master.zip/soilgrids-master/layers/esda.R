library(tidyverse)

source(paste0(Sys.getenv("SRCDIR"),"common/reg_matrix.R"))

tbl0 <- load_reg_matrix()

tbl=tbl0 %>% select(one_of(names(tbl0)[grep("[A-Z]",names(tbl0),invert=T)]))
tbl =  tbl %>% mutate(stdpt = case_when(
            get(Sys.getenv("DEPTH_COL")) <=  5 ~ 5,
            get(Sys.getenv("DEPTH_COL")) > 5 & get(Sys.getenv("DEPTH_COL")) <= 15 ~ 15,
            get(Sys.getenv("DEPTH_COL")) > 15 & get(Sys.getenv("DEPTH_COL")) <= 30 ~ 30,
            get(Sys.getenv("DEPTH_COL")) > 30 & get(Sys.getenv("DEPTH_COL")) <= 60 ~ 60,
            get(Sys.getenv("DEPTH_COL")) > 60 & get(Sys.getenv("DEPTH_COL")) <= 100 ~ 100,
            get(Sys.getenv("DEPTH_COL")) > 100 & get(Sys.getenv("DEPTH_COL")) <= 200 ~ 200,
            get(Sys.getenv("DEPTH_COL")) > 200 | is.na(get(Sys.getenv("DEPTH_COL"))) ~ 201,
            ))                                                


skimr::skim(tbl %>% select(one_of(as.character(Sys.getenv("VOI")),as.character(Sys.getenv("DEPTH_COL"))))) %>% skimr::kable()

sink(paste0(Sys.getenv("PLOTDIR"),"summary_table_",Sys.getenv("VOI"),".md"))
skimr::skim(tbl %>% group_by(stdpt) %>% select(one_of(as.character(Sys.getenv("VOI"))))) %>% skimr::kable(format="markdown")
sink()



# tbl_tmp=tbl %>% filter(depth<0 & profile_id<1000000) %>% select(one_of("profile_id","depth"))

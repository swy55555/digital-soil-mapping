# Performs the selection of covariates on a given set of cross-validation folds 
# (usually 3). Computationally expensive for larger numbers of folds. This 
# programme is primarilly meant to run with several dozens of CPU.
#
# Author: Luís de Sousa luis (dot) desousa (at) isric (dot) org
# Author: Laura Poggio laura (dot) poggio (at) isric (dot) org
# Date: 01-04-2019
# 
# Copyright (c) 2019 ISRIC - World Soil Information. All rights reserved.
# Any use of this software constitutes full acceptance of all terms of the
# document licence.
# SPDX-License-Identifier:  
###############################################################################

library(tidyverse)
library(caret)

args = commandArgs(TRUE)

if (length(args)==0) {
args=c("10",paste0(Sys.getenv("COVS_ALL"),"_corr"), "1", "1", "oc") # 
} 

fldsrc=Sys.getenv("SRCDIR")
source(paste0(fldsrc,"/common/ggplot_conf.R"))
source(paste0(fldsrc,"/common/reg_matrix.R"))
source(paste0(fldsrc,"/covariates/funs_rfe_ranger.R"))
source(paste0(fldsrc,"/covariates/funs_rfe_apply.R"))

covs_list=read.table(args[1])[,1]
f = as.numeric(unlist(strsplit(args[2],","))) # folds
svar=args[3]

tbl0 <- load_reg_matrix()

tbl=tbl0 %>% filter(complete.cases(.))

lst_covs_rfe=list(tolower(unique(c(Sys.getenv("DEPTH_COL"),as.character(covs_list)))))

if(f!=0){
	df=tbl %>% filter(fold %in% f,) %>% select(one_of(c(svar,lst_covs_rfe[[1]])))
} else {
    df=tbl %>% select(one_of(c(svar,lst_covs_rfe[[1]])))
}

ctrl <- rfeControl(functions = rangerFuncs,
    method = "repeatedcv",
    number = 2,
    returnResamp="all",
    saveDetails = TRUE,
    verbose = TRUE,
    allowParallel = TRUE)


lst_rfe_profile=list(fun_rfe_data(1,lst_covs_rfe,df,svar,ctrl))

saveRDS(lst_rfe_profile,file=paste0(Sys.getenv("RFEDIR"), "lst_rfe_profile_",svar,"_",f[1],".RDS"))

rfe_predictors=lapply(1:length(lst_rfe_profile), function(x){predictors(lst_rfe_profile[[x]])})
write.table(rfe_predictors[[1]],file=paste0(Sys.getenv("RFEDIR"), "lst_rfe_predictors_",svar,"_",f[1],".csv"), row.names=FALSE, col.names=FALSE)

df_rfe_results=lapply(1:length(lst_rfe_profile), function(x){data.frame(x=x,lst_rfe_profile[[x]]$results[,1:4])})
df_rfe_results = do.call("rbind", df_rfe_results)
df_rfe_results.m=reshape2::melt(df_rfe_results,id.vars = c("x", "Variables"))

pref=ggplot(df_rfe_results.m %>% filter(x, variable %in% c("RMSE","Rsquared"))) + geom_point(aes(x=Variables,y=value)) + geom_line(aes(x=Variables,y=value)) + facet_grid(variable ~ x, scales = "free") + scale_x_continuous(breaks= scales::pretty_breaks()) + thggp

png(paste0(Sys.getenv("RFEDIR"), "lst_rfe_profile_",svar,"_",f[1],".png"), width = 3800, height = 1800, units = 'px', res = 300)
print(pref)
dev.off()

write.csv(data.frame(df_rfe_results.m,fold=f[1]), paste0(Sys.getenv("RFEDIR"), "lst_rfe_profile_",svar,"_",f[1],".csv"), row.names=F)




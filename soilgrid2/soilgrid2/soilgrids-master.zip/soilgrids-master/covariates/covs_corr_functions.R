fun_corr_tbl=function(TBL)
{
	corr0=round(cor(TBL,use="complete.obs"), 2)
	corr0[is.na(corr0)] <- 0
	df.corr=data.frame(
		row=rownames(corr0)[row(corr0)[upper.tri(corr0)]], 
		col=colnames(corr0)[col(corr0)[upper.tri(corr0)]], 
		corr=corr0[upper.tri(corr0)]
	)
	df.corr_high=df.corr %>% filter(corr>=corr_coeff) %>% distinct(row)
	df.tbl_red=TBL[,!names(TBL) %in% df.corr_high[,1]]
	return(df.tbl_red)
}


fun_dend=function(TBL){
    corr0=round(cor(TBL,use="complete.obs"), 2)
    corr0[is.na(corr0)] <- 0
    
    dissimilarity = 1 - corr0
    distance = as.dist(dissimilarity) 
    clus <- hclust(distance)
    op_k <- maptree::kgs(clus, distance, maxclus = 20)
    kk=as.integer(names(op_k[which(op_k == min(op_k))]))

    cutclus=cutree(clus, k=kk)

    dend <- as.dendrogram(clus)
    dend <- color_labels(dend, k = kk)
    dend <- color_branches(dend, k = kk)
    dend <- set(dend, "labels_cex", 0.5)
return(dend) }

fun_corr=function(TBL){
    corr0=round(cor(TBL,use="complete.obs"), 2)
    corr0[is.na(corr0)] <- 0
    return(corr0)
}

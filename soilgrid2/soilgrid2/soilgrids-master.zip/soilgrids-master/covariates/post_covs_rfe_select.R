library(tidyverse)
library(zoo)
args = commandArgs(TRUE)

if (length(args)==0) {
args=c("soc") # 
}


fldsrc=Sys.getenv("SRCDIR")
source(paste0(fldsrc,"/common/ggplot_conf.R"))
svar=args[1]

files=dir(Sys.getenv("RFEDIR"), pattern = "*.csv")
files=files[grep("lst_rfe_profile_",files)]
files=files[grep(svar,files)]

dtcsv=data_frame(filename = files) %>% # create a data frameholding the file names
  mutate(file_contents = map(filename,          # read files into a new data column
           ~ read_csv(file.path(Sys.getenv("RFEDIR"), .))) 
        ) %>% unnest()


dtk_stats=dtcsv %>% filter(variable=="RMSE") %>% 
	group_by(Variables) %>% 
    summarize(
       	kq50=median(value), 
        kq05=quantile(value, probs=0.05), 
        kq95=quantile(value, probs=0.95),
        km=mean(value)) 

idx_deriv=zoo::rollapply(zoo::as.zoo(dtk_stats$kq50), 4, function(x) which.min(x)==2)
idx_deriv=idx_deriv[coredata(idx_deriv)]
idx_deriv=as.numeric(row.names(as.data.frame(idx_deriv)))

nvars=as.numeric(dtk_stats %>% slice(idx_deriv[1]) %>% select(Variables))

pp=ggplot(dtk_stats) + geom_line(aes(x=Variables,y=kq50)) + 
        geom_vline(xintercept=nvars, col="blue", lty=2) +
        geom_text(aes(x=nvars, label=nvars, y=round(max(dtk_stats$kq50)))) +
        xlab("N variables") + ylab("Median RMSE") + 
        thggp + theme(axis.title.x = element_text(size = 14),
        axis.title.y = element_text(size = 14))

png(paste0(
	Sys.getenv("RFEDIR"), "RFE_fold_RMSE_",svar,".png"), 
	width = 3800, 
	height = 1800, 
	units = 'px', 
	res = 300
	)
print(pp)
dev.off()


rdata=dir(Sys.getenv("RFEDIR"), pattern = "*.RDS")
rdata=rdata[grep("lst_rfe_profile",rdata)]
rdata=rdata[grep(svar,files)]

fun_rdata=function(x,FLIST)
{
	lst_rfe_profile=readRDS(paste0(Sys.getenv("RFEDIR"),FLIST[x]))
	df.imp=data.frame(
		variable=names(lst_rfe_profile[[1]]$fit$variable.importance), 
		importance=lst_rfe_profile[[1]]$fit$variable.importance,fold=x
		)
	return(df.imp)
}
# fit

ls.imp=lapply(1:length(rdata),function(x){fun_rdata(x,rdata)})

# differences between vectors 

full_covs=data.frame(
	full_covs=c(
		Sys.getenv("DEPTH_COL"),
		tolower(as.character(read.table(paste0(Sys.getenv("COVS_ALL"),"_overl"))[,1])))
	)
	
df.covs=data.frame(
	covs=full_covs,
	do.call(cbind, 
		lapply(
			1:length(rdata),
			function(x){
				ifelse(full_covs$full_covs %in% as.character(ls.imp[[x]]$variable),1,0)
			})
		)
	)

df.rfe=data.frame(covs=df.covs[,1],tot=rowSums(df.covs[,-(1)]))

df.rfe.sel = df.rfe %>% filter(tot>0) %>% arrange(desc(tot))
write.csv(data.frame(df.rfe.sel), paste0(Sys.getenv("RFEDIR"), "df_rfe_sel_",svar,".csv"), row.names=FALSE)

# cutoff RFE (i.e > 3) --> RFE with all points

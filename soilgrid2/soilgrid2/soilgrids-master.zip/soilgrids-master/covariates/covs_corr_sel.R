library(rgrass7)
library(RSQLite)
library(tidyverse)

library(gridExtra )
library(ggcorrplot)
library(dendextend)

use_sp()

args = commandArgs(TRUE)

if (length(args)==0) {
args=c("0.85") # 
} 



# NOTE: correlation between binary variables can be addressed with the phi coefficient : sqrt(chisq.test(table(dat[,1],dat[,2]), correct=FALSE)$statistic/length(dat[,1]))
# NOTE: for larger values pearson correlation coefficient is a good approximation
# NOTE: https://stats.stackexchange.com/questions/26105/what-is-the-difference-between-verifying-how-strong-is-the-relationship-of-varia/26111#26111

source(paste0(Sys.getenv("SRCDIR"),"covariates/covs_corr_functions.R"))

fldsrc=Sys.getenv("SRCDIR")

corr_coeff=as.numeric(args[1])
# # # na_thrd=0.85

con = dbConnect(SQLite(), dbname=paste0(Sys.getenv("GDIR"),"/",Sys.getenv("GLOC"),"/",Sys.getenv("MAPSET_PROFS"),"/sqlite/sqlite.db"))
dbListTables(con) # List all tables in DB

# tbl=dbReadTable(con, Sys.getenv("PROFILES_COVS")) # read table in R from sqlite of GRASS
tbl=dbReadTable(con, paste0(Sys.getenv("GLOBAL_MESH"),"_covs")) # read table in R from sqlite of GRASS
dbDisconnect(con)

covs_list=as.character(read.table(paste0(Sys.getenv("COVS_ALL"),"_overl"))[,1])

df.tbl=tbl[,names(tbl) %in% covs_list]
# # # df.tbl=df.tbl[complete.cases(df.tbl),]

source(paste0(Sys.getenv("SRCDIR"),"covariates/covs_corr_module.R"))

png(paste0(Sys.getenv("PLOTDIR"),"/select_covs_corr_",corr_coeff,".png"), width = 5000, height = 4000, units = 'px', res = 300)
print(ggpc1)
dev.off()

write.table(names(df.tbl.sel), file=paste0(Sys.getenv("COVS_ALL"),"_corr_",corr_coeff), row.names=F, col.names=F, quote=F)

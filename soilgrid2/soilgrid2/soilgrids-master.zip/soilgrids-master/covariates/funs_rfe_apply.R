

fun_rfe_data=function(x,LST,DAT,VAR,CTRL){
    df.covs=DAT[,names(DAT) %in% LST[[x]] ]
    vary=DAT[,VAR ]

        if (ncol(df.covs)<=15) {
            sizes=unique(c(seq(0,ncol(df.covs),3),ncol(df.covs)))
        } else if (ncol(df.covs) > 15 & ncol(df.covs) <= 75) {
            sizes=unique(c(seq(0,15,3),seq(15,ncol(df.covs),5),ncol(df.covs)))
        } else if (ncol(df.covs) > 75) {
            sizes=unique(c(seq(0,15,3),seq(15,75,5),seq(75,ncol(df.covs),20),ncol(df.covs)))
        }

    lmProfile <- rfe(df.covs, vary, sizes = sizes, rfeControl = CTRL)

}


# ### ### Remove one covariate for each pair with a correlation > corr_coeff
t1=df.tbl; t2=data.frame()
while(ncol(t2)<ncol(t1)){
t2=fun_corr_tbl(t1)
if(ncol(t2)==ncol(t1)) {df.tbl.sel=t2} else {t1=t2; t2=data.frame()}
}

# ### ### Remove covariates where NA > na_thrd
# # # na_sel=apply(df.tbl.sel, 2, function(x) ifelse(sum(ifelse(is.na(x),1,0))/nrow(df.tbl.sel) > na_thrd, 1,0))
# # # na_sel=na_sel[na_sel ==1]
# # # 
# # # if(length(na_sel) > 0) {df.tbl.sel=df.tbl.sel[,!names(df.tbl.sel) %in% na_sel]}
df.tbl.sel=df.tbl.sel[,names(df.tbl.sel) != "profile_id"]


dend0=fun_dend(df.tbl)
dend1=fun_dend(df.tbl.sel)

png(paste0(Sys.getenv("PLOTDIR"),"/all_covs_corr_cluster_",corr_coeff,".png"), width = 5000, height = 5000, units = 'px', res = 500)
plot(dend0, main="Dissimilarity = 1 - Correlation", xlab="", cex=0.6) 
dev.off()

png(paste0(Sys.getenv("PLOTDIR"),"/select_covs_corr_cluster_",corr_coeff,".png"), width = 5000, height = 5000, units = 'px', res = 500)
plot(dend1, main="Dissimilarity = 1 - Correlation", xlab="", cex=0.6) 
dev.off()


fun_corr=function(TBL){
    corr0=round(cor(TBL,use="complete.obs"), 2)
    corr0[is.na(corr0)] <- 0
    return(corr0)
}

corr0=fun_corr(df.tbl)
corr1=fun_corr(df.tbl.sel)

ggpc0=ggcorrplot(corr0, type = "lower", ggtheme = ggplot2::theme_gray, outline.col = "white", colors = c("#6D9EC1", "white", "#E46726"), tl.cex = 8) + theme(text = element_text(size=16), axis.text.x = element_text(angle=90, hjust=1)) 

ggpc1=ggcorrplot(corr1, type = "lower", ggtheme = ggplot2::theme_gray, outline.col = "white", colors = c("#6D9EC1", "white", "#E46726"), tl.cex = 8) + theme(text = element_text(size=16), axis.text.x = element_text(angle=90, hjust=1)) 

png(paste0(Sys.getenv("PLOTDIR"),"/all_covs_corr_",corr_coeff,".png"), width = 5000, height = 4000, units = 'px', res = 300)
print(ggpc0)
dev.off()

source(paste0(Sys.getenv("SRCDIR"),"/models/",Sys.getenv("MODEL"),"/predict_qrf_fun.R"))

fun_pred_qrf_dpt=function(data,model,depthMid)
{
	message(paste0("Predicting for depth: ", depthMid))
    df=data
    df[,Sys.getenv("DEPTH_COL")]=depthMid

#     system.time({predQRF <- predict(model, df, type = "quantiles", quantiles = quantiles) }) # Missing mean
    predQRF <- predict.ranger.tree(model, data = df, type="treepred", num.threads=1)
    return(c(data[,c("x","y")],predQRF))
#     return(predQRF)
}


fun_pred_qrf=function(data,model,depthMid)
{
    df=data
    predQRF <- predict.ranger.tree(model, data = df, type="treepred", num.threads=1)
    return(c(data[,c("x","y")],predQRF))
}



compute_quants=function(predQRF, quantiles){
    pred_quants <- data.frame(t(apply(predQRF$predictions, 1, quantile, quantiles, na.rm=TRUE))); 
        names(pred_quants)=paste0("Q",quantiles)
    pred_mean <- data.frame((apply(predQRF$predictions, 1, mean, na.rm=TRUE))); 
        names(pred_mean)=paste0("mean")
    quants_pred=cbind(pred_quants,pred_mean)
    return(quants_pred)
}






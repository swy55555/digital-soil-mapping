library(tidyverse)
library(ranger)

source(paste0(Sys.getenv("SRCDIR"),"/common/reg_matrix.R"))

message("Checking arguments")

args = commandArgs(TRUE)

if (length(args)==0) {
args=c("10",Sys.getenv("COVS_VOI"), "12", "150") #
} 

ncpus=as.numeric(args[1])
covs_list=read.table(args[2])[,1]
mtry=as.numeric(args[3])
ntree=as.numeric(args[4])
svar=args[5]

tbl0 <- load_reg_matrix()
message("Read the table")

tbl=tbl0 %>% filter(complete.cases(.)) #%>% filter(depth<=10) %>%  drop_na(oc) %>% drop_na() %>% sample_n(1000)

lst_covs_rfe=list(unique(c(Sys.getenv("DEPTH_COL"),as.character(covs_list))))

fmla=as.formula(paste0(svar,"~",paste0(lst_covs_rfe[[1]],collapse="+")))

system.time({mod = ranger(fmla,tbl,importance="impurity", quantreg=TRUE, num.threads=ncpus, mtry=mtry, num.trees=ntree)}) # fit the model
saveRDS(mod, file=paste0(Sys.getenv("MODDIR"),"/",svar,"_model.RDS"))

# Cross-validation with Quantile Regression Forests
#
# Author: Luís de Sousa luis (dot) desousa (at) isric (dot) org
# Author: Laura Poggio laura (dot) poggio (at) isric (dot) org
# Date: 03-05-2019
# 
# Copyright (c) 2019 ISRIC - World Soil Information. All rights reserved.
# Any use of this software constitutes full acceptance of all terms of the
# document licence.
# SPDX-License-Identifier:  
###############################################################################

source(paste0(Sys.getenv("SRCDIR"),"/common/fun_metrics.R"))
source(paste0(Sys.getenv("SRCDIR"),"/models/",Sys.getenv("MODEL"),"/predict_qrf_fun.R"))

fmla=as.formula(paste0(svar,"~",paste0(lst_covs_rfe[[1]],collapse="+")))

# Ranger is randomly returning crippled models. In such cases a new fit is 
# attempted. Limited to 10 attempts.
i <- 0
while(i < 10) 
{
  tryCatch(
  {
      	system.time({ mod = ranger( # fit the model
      		fmla,df.cal,importance="impurity", 
      		quantreg=TRUE, 
      		mtry=mtry, 
      		num.trees=ntree)
      	})
		system.time({pred.tree = # predict the model on a new dataset
			predict.ranger.tree(mod, data = df.val, type="treepred")
		})		 
		i <<- 10
		message("Model fit sucessful.")
  }, 
  error = function(err) 
  {
  	i <<- i + 1
  	message(paste0("[!] Error running ranger: ", err))
    message(paste0("New fitting attempt: ", i))
  })
}

if(Sys.getenv("TRANSFORM")!="") {saveRDS(pred.tree$predictions,file=paste0(Sys.getenv("CVDIR"), "CV_TreesPreds_",svar,"_fold_",f,"_mtry_",mtry,"_ntree_",ntree,".RDS"))}

pred_quants <- data.frame(t(apply(pred.tree$predictions, 1, quantile, quants, na.rm=TRUE))); names(pred_quants)=paste0(svar,"_quant_",quants)
pred_mean <- data.frame((apply(pred.tree$predictions, 1, mean, na.rm=TRUE))); names(pred_mean)=paste0(svar,"_mean")

if(Sys.getenv("MOD2D")==TRUE){
    df.pred=data.frame(df.val[,c("id_profile","lon","lat","x","y","stratum","fold",
            svar,as.character(unlist(strsplit(Sys.getenv("VOI"),","))))],
            mtry=mtry,ntree=ntree,pred_quants,pred_mean)    
} else {
    df.pred=data.frame(df.val[,c("id_profile","lon","lat","x","y","stratum","fold","top","bottom",
            Sys.getenv("DEPTH_COL"),svar,as.character(unlist(strsplit(Sys.getenv("VOI"),","))))],
            mtry=mtry,ntree=ntree,pred_quants,pred_mean)
}

system.time({saveRDS(df.pred, file=paste0(Sys.getenv("CVDIR"), "CV_predictions_",svar,"_fold_",f,"_mtry_",mtry,"_ntree_",ntree,".RDS"))}) # reading from RDS is much faster than reading from sqlite

rr_med=fun_metrics(df.pred[,svar],df.pred[,paste0(svar,"_quant_0.5")])
rr_mean=fun_metrics(df.pred[,svar],df.pred[,paste0(svar,"_mean")])

write.csv(data.frame(median=rr_med,mean=rr_mean,mtry=mtry,ntree=ntree,fold=f), file=paste0(Sys.getenv("CVDIR"), "CV_metrics_",svar,"_fold_",f,"_mtry_",mtry,"_ntree_",ntree,".csv"))

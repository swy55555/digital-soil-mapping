# read in geotif (tile) to be backtransformed
# write new geotif
# do not delete before checking that the new geotiff has data in it

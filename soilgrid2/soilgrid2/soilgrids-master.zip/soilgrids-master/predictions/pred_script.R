# Executes predictions for a single tile of the final map. Loads to memory all
# the required covariates for the specific tile. The GRASS region is set to the
# tile thus restricting the covariates to the extent of the tile. After the 
# prediction model is applied, the result is saved as a GeoTiff.
#
# Author: Luís de Sousa luis (dot) desousa (at) isric (dot) org
# Author: Laura Poggio laura (dot) poggio (at) isric (dot) org
# Date: 22-01-2019
# 
# Copyright (c) 2019 ISRIC - World Soil Information. All rights reserved.
# Any use of this software constitutes full acceptance of all terms of the
# document licence.
# SPDX-License-Identifier:  
###############################################################################

library(rgrass7)
library(raster)
library(ranger)
library(pbapply)
library(dplyr)

use_sp()

source(paste0(Sys.getenv("SRCDIR"),"/common/depths.R"))

# loc <- initGRASS(gisBase = "/usr/lib64/grass74/", home=getwd(), gisDbase="/home/lpoggio/data/localsdb/GRASSDATA",location="Argentina_4326", mapset=paste0("pred_2015"), override=TRUE )
# loc is an example on how to start a session of GRASS from within R. It is not necessary in this case, because Rscript is called from within a grass location and mapset.

args = commandArgs(TRUE)

if(length(args) < 2)
{
	message(paste0("Please provide the tile name and the subtile identifier."))	
	quit(save="no")
}


tile=paste0(args[1], "_", args[2])
# tile="tileSG-002-057_2-4"

depths_int=getDepthsVector()
depths_dirs=getDepthsFolders()
depths_mids <- getDepthsMidPoints()

quants=as.numeric(unlist(strsplit(Sys.getenv("QUANTS"),",")))

# ------------------- loop for each transformed variable
for (svar in unlist(strsplit(Sys.getenv("VOITR"),","))){ 
source(paste0(Sys.getenv("SRCDIR"),"/predictions/pred_internal.R"))

assign(paste0("pred_",svar),predictions)
rm(predictions)
}

rm(mod); rm(rst)
# # # message("loading workspace")
# # # load("./tmp_store/workspace_text_lp.RData")
# --------------------------------------

pryr::mem_used()


# --------------------------------------
# back-transformation if necessary
# --------------------------------------

if(Sys.getenv("TRANSFORM")=="") {
    predictions=get(paste0("pred_",svar));
    source(paste0(Sys.getenv("SRCDIR"),"/predictions/pred_quants_notransform.R"))

} else {
# library(pryr) # for memory debugging
# Rprof( pfile <- "rprof.log", memory.profiling=TRUE) # uncomment to profile the memory consumption

    source(paste0(Sys.getenv("SRCDIR"),"layers/data_transform/predict_back_",Sys.getenv("TRANSFORM"),".R"))

# Rprof(NULL)
}

# # # library(pryr); library(tidyverse)
# # # a=summaryRprof("rprof.log",memory="both")
# # # as.data.frame(a$by.total$mem.total) %>% add_rownames() %>% arrange(desc(V1)) %>% head(10)





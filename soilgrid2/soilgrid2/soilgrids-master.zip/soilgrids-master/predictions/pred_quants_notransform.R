if(Sys.getenv("MOD2D")==TRUE){
    quantiles=compute_quants(predictions, quants)

            fun_write_rst(
                coords=df_pred[,c("x","y")],
                predQuants=quantiles,
                crsrst=crs_rst,
                tile=tile,
                depthsDir=depths_dirs)
            
} else {
    quantiles=lapply(1:length(predictions), function(x)
    {
        message(paste0("Compute quantiles for predictions: ", depths_mids[x]))            
        compute_quants(predictions[[x]], quants)
    })

    lapply(1:length(quantiles),function(x){
            fun_write_rst(
                coords=df_pred[,c("x","y")],
                predQuants=quantiles[[x]],
                crsrst=crs_rst,
                tile=tile,
                depthsDir=depths_dirs[x])
            })
}

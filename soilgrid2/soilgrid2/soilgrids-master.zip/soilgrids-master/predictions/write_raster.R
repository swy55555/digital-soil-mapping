fun_write_rst=function(coords,predQuants,crsrst,tile,depthsDir,VOI=Sys.getenv("VOI")){
    df.res=data.frame(coords,predQuants)
    coordinates(df.res)=~x+y 
	gridded(df.res)=TRUE 
	rst.res=brick(df.res)
	proj4string(rst.res)=crsrst
    
    lapply(1:nlayers(rst.res), function(y)
	{
		scaled_rst <- rst.res[[y]] * as.numeric(Sys.getenv("SCALE_FACTOR"))
        newRasterPath <- paste0(
        	Sys.getenv("PREDIR"), "/tiff/", 
			VOI, "_", depthsDir, "_", names(rst.res[[y]]), "/", 
			strsplit(tile,"_")[[1]][1])
        dir.create(newRasterPath, recursive=TRUE)
		newRaster <- paste0(newRasterPath, "/", tile, ".tiff")
		message(paste0("Writing new raster: ", newRaster))
		writeRaster(
			#rst.res[[y]], 
			scaled_rst,
			filename=newRaster,
			datatype="INT2S",
 			options="COMPRESS=DEFLATE, BIGTIFF=YES, PREDICTOR=2", 
			overwrite=TRUE)
	})
}

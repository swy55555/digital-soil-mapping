library(Metrics)
library(verification)
library(DescTools)

fun_metrics=function(obs,pred){

mean.obs <- mean(obs, na.rm=T)
TSS <- sum((obs-mean.obs)^2)
	
ccc <- CCC(obs, pred, ci="z-transform", conf.level=0.95)
	
met <- c(
		rmse(obs, pred),
		rmse(obs, pred)/mean.obs,
		bias(obs, pred),
		mse(obs, pred), 
		mae(obs, pred),
		mean(obs - pred),
		1 - (sse(obs, pred) / TSS),  # equivalent to [1 - (mse(obs, pred)/var(obs))]
		summary(lm(obs ~ pred))$r.squared,
		ccc[1]$rho.c$est,
		ccc[4]$C.b
	)
names(met)=c("rmse","Nrmse","bias","mse","mae","me","SSmse","R2lm","ccc_rho","ccc_bias")
return(met)
# add something from verification package
}

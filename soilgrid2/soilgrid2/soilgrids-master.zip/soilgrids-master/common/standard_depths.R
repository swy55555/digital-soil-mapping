# To get a standard depth label for each horizon

# # # tbl.lyr =  tbl.lyr %>% mutate(stdpt = case_when(
# # #                         dpt <=  5 ~ 5,
# # #                         dpt > 5 & dpt <= 15 ~ 15,
# # #                         dpt > 15 & dpt <= 30 ~ 30,
# # #                         dpt > 30 & dpt <= 60 ~ 60,
# # #                         dpt > 60 & dpt <= 100 ~ 100,
# # #                         dpt > 100 & dpt <= 200 ~ 200,
# # #                         dpt > 200 | is.na(dpt) ~ 201,
# # #                         ))                                                

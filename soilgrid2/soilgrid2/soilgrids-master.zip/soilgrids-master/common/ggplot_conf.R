library(ggplot2)
# ### ### Loading
cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7", "#999999")
mPalette <- RColorBrewer::brewer.pal(12,"Paired")

thggp=theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black"), axis.text.x=element_text(size=14, colour="black"), axis.text.y=element_text(size=14, colour="black"), legend.title=element_blank())
thggpfacet=theme(strip.text.y = element_text(size=14, colour="black", face="bold.italic"), strip.text.x = element_text(size=9, colour="black", face="bold.italic"), panel.background = element_rect(fill = NA, color = "black"))
thggtitle=theme(plot.title = element_text(lineheight=.8, face="bold", size=16))

thggp_line=theme_bw() + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), axis.text.x=element_text(size=14, colour="black"), axis.text.y=element_text(size=14, colour="black"), legend.title=element_blank())





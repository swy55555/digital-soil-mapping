# Loads the regression matrix from a Postgres database
#
# Author: Luís de Sousa luis (dot) desousa (at) isric (dot) org
# Author: Laura Poggio laura (dot) poggio (at) isric (dot) org
# Date: 18-09-2019
# 
# Copyright (c) 2019 ISRIC - World Soil Information. All rights reserved.
# Any use of this software constitutes full acceptance of all terms of the
# document licence.
# SPDX-License-Identifier:  
###############################################################################

library(RPostgreSQL)

prefix <- "regr_matrix_all_"
table_name <- paste0(prefix, gsub(",","_",Sys.getenv("VOI")), "_",Sys.getenv("RUN"))

get_conn <- function()
{
	return(
		dbConnect(PostgreSQL(), 
		host=Sys.getenv("PG_HOST"), 
		port=Sys.getenv("PG_PORT"), 
	    user=Sys.getenv("PG_USER"), 
	    password=Sys.getenv("PG_PASS"), 
	    dbname=Sys.getenv("PG_DB"))
	)
}

load_reg_matrix <- function()
{
	connPg <- get_conn()
	
	myTable <- dbReadTable(
		connPg,
		c(Sys.getenv("PG_SCHEMA_MAT"), table_name)
	)
	
	dbDisconnect(connPg)
	
	return(myTable)
}	

save_reg_matrix <- function(tbl)
{
	connPg <- get_conn()
	
	dbWriteTable(
		connPg,
		c(Sys.getenv("PG_SCHEMA_MAT"), table_name),
		tbl,
		overwrite=TRUE
	)
	# Open table in read mode to other users
	dbSendQuery(connPg, paste0("GRANT SELECT ON matrices.\"", table_name, "\" TO staff;"))
			
	dbDisconnect(connPg)
	
	# Save also to RDS file, as requested in #157
	saveRDS(tbl, file=paste0(Sys.getenv("MODDIR"), 
			"regr_matrix_",gsub(",","_",Sys.getenv("VOI")),".RDS"))		
}

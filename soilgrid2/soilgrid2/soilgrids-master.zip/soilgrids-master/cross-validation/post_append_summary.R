# Summarises outputs of K-fold cross-validation with graphs and a specific RDS.
# This summary is to be carefully inspected, it helps selecting the final
# hyper-parameters of models (e.g. mtry and number of trees in Random Forests).
#
# Author: Luís de Sousa luis (dot) desousa (at) isric (dot) org
# Author: Laura Poggio laura (dot) poggio (at) isric (dot) org
# Date: 29-05-2019
# 
# Copyright (c) 2019 ISRIC - World Soil Information. All rights reserved.
# Any use of this software constitutes full acceptance of all terms of the
# document licence.
# SPDX-License-Identifier:  
###############################################################################

library(tidyverse)

args = commandArgs(TRUE)
if (length(args)==0) {
args=c(Sys.getenv("VOI")) # 
}


fldsrc=Sys.getenv("SRCDIR")
source(paste0(fldsrc,"/common/ggplot_conf.R"))
svar=args[1]

# ### main summary metrix
df_metrics=read.csv(paste0(Sys.getenv("CVDIR"), "CV_metrics_append_",svar,".csv"))

df_plot=df_metrics %>% group_by(mtry,ntree,metric) %>% summarize(median=median(median), mean=mean(mean))

pp= ggplot(df_plot) + 
    geom_line(aes(x=mtry,y=median,col=as.factor(ntree))) + 
    facet_wrap(.~ metric,scales="free") + 
    scale_color_manual(values=cbbPalette) + 
    scale_x_continuous(breaks=unique(df_plot$mtry), labels=unique(df_plot$mtry)) +
    thggp + thggpfacet
    
    
png(paste0(Sys.getenv("CVDIR"), "CVHYP_summary_median_",svar,".png"), width = 3800, height = 1800, units = 'px', res = 300)
print(pp)
dev.off()

pp= ggplot(df_plot) + 
    geom_line(aes(x=mtry,y=mean,col=as.factor(ntree))) + 
    facet_wrap(.~ metric,scales="free") + 
    scale_color_manual(values=cbbPalette) + 
    scale_x_continuous(breaks=unique(df_plot$mtry), labels=unique(df_plot$mtry)) +
    thggp + thggpfacet
    
    
png(paste0(Sys.getenv("CVDIR"), "CVHYP_summary_mean_",svar,".png"), width = 3800, height = 1800, units = 'px', res = 300)
print(pp)
dev.off()


# ### Confidence intervals
df_all=readRDS(paste0(Sys.getenv("CVDIR"), "CV_predictions_append_",svar,".RDS"))

df_ci = df_all %>% select(one_of(c("fold","mtry","ntree",paste0(svar,"_quant_0.05"),paste0(svar,"_quant_0.95")))) %>% 
                  rename("q05"=paste0(svar,"_quant_0.05"),q95=paste0(svar,"_quant_0.95")) %>%
                  mutate(CI=q95-q05)

df_cipp=df_ci %>% group_by(mtry,ntree) %>% summarize(CI=mean(CI, na.rm=T))


ppi= ggplot(df_cipp) + 
    geom_line(aes(x=mtry,y=CI,col=as.factor(ntree))) + 
    scale_color_manual(values=cbbPalette) + 
    scale_x_continuous(breaks=unique(df_cipp$mtry), labels=unique(df_cipp$mtry)) +
    thggp + thggpfacet

png(paste0(Sys.getenv("CVDIR"), "CVHYP_summary_CI_",svar,".png"), width = 3800, height = 1800, units = 'px', res = 300)
print(ppi)
dev.off()

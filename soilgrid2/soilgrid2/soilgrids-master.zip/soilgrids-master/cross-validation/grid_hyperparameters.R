args = commandArgs(TRUE)

if (length(args)==0) {
args=c(Sys.getenv("COVS_LIST"), "1,1.5,2,3", "75,100,150,200,250,500,750,1000") # 
}

covs_list=read.table(args[1])[,1]
mtrys=round(as.numeric(unlist(strsplit(args[2],",")))*round(sqrt(length(covs_list))))
if(max(mtrys) > length(covs_list)){mtrys[which.max(mtrys)]=max(mtrys)}
ntrees=as.numeric(unlist(strsplit(args[3],",")))
var=args[4]

grid_hyp=expand.grid(mtrys,ntrees)
names(grid_hyp)=c("mtry","ntree")

write.table(grid_hyp, file=paste0(Sys.getenv("PARAMDIR"),"grid_hyperparameters_", var, ".csv"), sep=",", row.names=F, col.names=F)

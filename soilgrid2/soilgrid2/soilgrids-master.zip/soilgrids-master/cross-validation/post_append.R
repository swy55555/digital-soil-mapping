library(tidyverse)

args = commandArgs(TRUE)
if (length(args)==0) {
args=c(Sys.getenv("VOI")) # 
}

svar=args[1]

files=dir(Sys.getenv("CVDIR"), pattern = paste0("CV_metrics*"))
files=files[grep("append",files, invert=TRUE)]
files=files[grep(svar,files)]


dtcsv0=data_frame(filename = files) %>% # create a data frameholding the file names
  mutate(file_contents = map(filename,          # read files into a new data column
           ~ read_csv(file.path(Sys.getenv("CVDIR"), .))) 
        ) %>% unnest()


dtcsv=as.data.frame(dtcsv0[,-(1)]) # remove filename column
names(dtcsv)[1]="metric"

write.csv(dtcsv, paste0(Sys.getenv("CVDIR"), "CV_metrics_fold_append_",svar,".csv"),row.names=F)


rdata=dir(Sys.getenv("CVDIR"), pattern = "CV_predictions*")
rdata=rdata[grep("append",rdata, invert=TRUE)]
rdata=rdata[grep(svar,rdata)]


dtrds0=data_frame(filename = rdata) %>% # create a data frameholding the file names
  mutate(file_contents = map(filename,          # read files into a new data column
           ~ readRDS(file.path(Sys.getenv("CVDIR"), .))) 
        ) %>% unnest()
saveRDS(dtrds0, paste0(Sys.getenv("CVDIR"), "CV_predictions_append_",svar,".RDS"))


source(paste0(Sys.getenv("SRCDIR"),"/common/fun_metrics.R"))
mets=c("rmse","Nrmse","bias","mse","mae","me","SSmse","R2lm","ccc_rho","ccc_bias")

rr_med0=dtrds0 %>% group_by(mtry,ntree) %>% summarize(m=list(fun_metrics(!!as.name(svar),!!as.name(paste0(svar,"_quant_0.5")))))
rr_med=cbind(as.data.frame(dtrds0 %>% group_by(mtry,ntree) %>% summarize(n = n())),do.call(rbind, rr_med0$m))
rr_med_m=reshape2::melt(rr_med,id=c("mtry","ntree"))
names(rr_med_m)[3:4]=c("metric","median")

rr_mean0=dtrds0 %>% group_by(mtry,ntree) %>% summarize(m=list(fun_metrics(!!as.name(svar),!!as.name(paste0(svar,"_mean")))))
rr_mean=cbind(as.data.frame(dtrds0 %>% group_by(mtry,ntree) %>% summarize(n = n())),do.call(rbind, rr_mean0$m))
rr_mean_m=reshape2::melt(rr_mean,id=c("mtry","ntree"))
names(rr_mean_m)[3:4]=c("metric","mean")

rr_mets=data.frame(rr_med_m,mean=rr_mean_m$mean) %>% filter(metric!="n") # TODO
write.csv(rr_mets, paste0(Sys.getenv("CVDIR"), "CV_metrics_append_",svar,".csv"),row.names=F)


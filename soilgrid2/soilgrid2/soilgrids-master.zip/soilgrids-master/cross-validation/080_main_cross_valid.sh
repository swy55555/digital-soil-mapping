# ### Cross-validation; run locally or prepare SLURM file(s) for HPC
source $SRCDIR/cross-validation/081_run_cross_valid.sh



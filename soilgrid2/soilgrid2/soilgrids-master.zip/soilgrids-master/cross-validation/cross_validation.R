library(tidyverse)
library(ranger)

source(paste0(Sys.getenv("SRCDIR"),"common/reg_matrix.R"))

args = commandArgs(TRUE)

if (length(args)==0) {
args=c("10",Sys.getenv("COVS_LIST"), "1", "10", "100", Sys.getenv("VOI")) # 
} 


covs_list=read.table(args[1])[,1]
f = as.numeric(args[2]) # fold
mtry=as.numeric(args[3]) # mtry
ntree=as.numeric(args[4]) # ntree
svar=args[5] # soil property

quants=as.numeric(unlist(strsplit(Sys.getenv("QUANTS"),",")))

tbl0 <- load_reg_matrix()
tbl=tbl0 %>% filter(complete.cases(.)) #%>% filter(depth<=10) %>%  drop_na(oc) %>% drop_na() %>% sample_n(1000)

if(Sys.getenv("MOD2D")==TRUE){
    lst_covs_rfe=list(unique(c(tolower(as.character(covs_list)))))    
} else {
    lst_covs_rfe=list(unique(c(Sys.getenv("DEPTH_COL"),tolower(as.character(covs_list)))))
}

df.cal=tbl %>% filter(fold!=f) #%>% select(one_of(c(svar,lst_covs_rfe[[1]])))
df.val=tbl %>% filter(fold==f) #%>% select(one_of(c(svar,lst_covs_rfe[[1]])))

source(paste0(Sys.getenv("SRCDIR"),"/models/",Sys.getenv("MODEL"),"/cross_val_qrf.R"))



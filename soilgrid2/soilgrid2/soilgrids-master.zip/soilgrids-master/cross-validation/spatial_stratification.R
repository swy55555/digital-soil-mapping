# Splits data into K groups for cross validation. The data is stratified 
# spatially with a discrete global grid.
#
# Author: Luís de Sousa luis (dot) desousa (at) isric (dot) org
# Author: Laura Poggio laura (dot) poggio (at) isric (dot) org
# Date: 12-03-2019
# 
# Copyright (c) 2019 ISRIC - World Soil Information. All rights reserved.
# Any use of this software constitutes full acceptance of all terms of the
# document licence.
# SPDX-License-Identifier:  
###############################################################################

library(rgrass7)
library(dggridR)
library(caret)
library(sp)

use_sp()

# --- Load synthetic profiles locations ---

# Initialise GRASS session
initGRASS(
		gisBase = Sys.getenv("GRASS_BASE"), 
		home = tempdir(), 
		gisDbase = Sys.getenv("GDIR"),
		location = Sys.getenv("GLOC"), 
		mapset = Sys.getenv("MAPSET_USER"),
		override=TRUE)

profiles <- readVECT(Sys.getenv("PROFILES_UNION"))
proj4string(profiles)=CRS(Sys.getenv("IGH"))

# ### add lat/lon
profiles_latlong <- data.frame(coordinates(spTransform(profiles, CRS(Sys.getenv("WGS84")))))
profiles$lon=profiles_latlong[,1]
profiles$lat=profiles_latlong[,2]
rm(profiles_latlong)

# --- Stratify and assign folds ---
set.seed(as.numeric(Sys.getenv("SETSEED")))
# Construct a global grid of desired resolution
dggs <- dgconstruct(res=as.numeric(Sys.getenv("DGG_RES")))

# Get the corresponding grid cells for each profile (coordinates must be passed as numbers)
profiles$stratum <- dgGEO_to_SEQNUM(dggs, profiles$lon, profiles$lat)$seqnum
message(paste0("Number of strata: ", length(unique(profiles$stratum))))

profiles$fold <- createFolds(
		factor(profiles$stratum), 
		k=as.numeric(Sys.getenv("NUM_FOLDS")),  
		list=FALSE) 

# --- Save to GRASS ---
# # # profiles_folds <- SpatialPointsDataFrame(
# # # 		profiles[,c("easting", "northing")], 
# # # 		profiles[,c("id_profile","lon","lat","stratum","fold")]) # LP: Safer to use full names especially with limited number of columns. 

writeVECT(profiles, Sys.getenv("PROFILES_FOLD"), v.in.ogr_flags=c("o","overwrite"))

